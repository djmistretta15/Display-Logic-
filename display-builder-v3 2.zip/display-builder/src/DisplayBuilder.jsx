import { useState, useEffect, useRef, useCallback } from "react";
import DisplayRenderer3D from "./DisplayRenderer3D";

// Load IBM Plex fonts
const fontLink = document.createElement('link');
fontLink.rel = 'stylesheet';
fontLink.href = 'https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700;800&family=IBM+Plex+Mono:wght@400;500;700&display=swap';
document.head.appendChild(fontLink);
import { DL_SYSTEM_PROMPT, FEASIBILITY_PROMPT, PDF_NARRATIVE_PROMPT } from "./DL_KNOWLEDGE_BASE";

const C = {
  // Light industrial — clean, high-contrast, professional
  bg:       "#F0F2F5",       // warm light gray page background
  surface:  "#FFFFFF",       // pure white cards/panels
  card:     "#FAFBFC",       // off-white secondary card
  border:   "#DDE2EA",       // soft gray borders
  borderBright:"#B8C4D4",    // medium border on hover/active
  borderActive:"#1B4FD8",    // accent blue active border

  accent:   "#1B4FD8",       // deep royal blue — authority
  accentDim:"#1E40AF",       // darker blue for hover
  accentGlow:"rgba(27,79,216,0.08)", // blue tint bg

  gold:     "#B45309",       // amber — warnings (darker for readability on white)
  goldBg:   "#FEF3C7",
  green:    "#047857",       // deep green — success
  greenBg:  "#D1FAE5",
  red:      "#B91C1C",       // deep red — error
  redBg:    "#FEE2E2",
  violet:   "#5B21B6",       // deep violet — pending
  violetBg: "#EDE9FE",

  text:     "#0F172A",       // near-black — primary text
  textMid:  "#475569",       // slate — secondary text
  textDim:  "#94A3B8",       // light slate — labels/placeholder
  textInv:  "#FFFFFF",       // white text on dark bg

  // Topbar stays dark navy for brand authority
  navBg:    "#0F1C3F",
  navBorder:"#1E3A6E",
  navText:  "#E2E8F0",
  navDim:   "#64748B",
};

const DATA = {
  applications:["Military / Defense","Medical / Healthcare","Industrial / Factory","Outdoor / Kiosk / EV Charging","Transit / Vehicle","Digital Signage","Retail / POS","Gaming / Arcade","Marine / Avionics","IoT / Embedded","Commercial / Other"],
  signalSources:["PC / Computer","Media Player","Single Board Computer (SBC)","Raspberry Pi","NVIDIA Jetson","PLC / HMI Controller","DVR / NVR","Set-Top Box","Custom Board","Other"],
  panelTypes:["TFT-LCD","STN-LCD","OLED","EL","EPD","LCOS","PDP"],
  orientations:["Landscape","Portrait","Reverse Landscape","Reverse Portrait"],
  operatingTemps:["-40C","-30C","-20C","-10C","0C","10C","20C","40C","50C","60C","70C","80C","85C","100C"],
  brightness:["100 nit","200 nit","300 nit","400 nit","500 nit","600 nit","700 nit","800 nit","1000 nit","1200 nit","1500 nit","2000 nit+"],
  backlightLife:["10,000 hrs","20,000 hrs","30,000 hrs","50,000 hrs","70,000 hrs","100,000 hrs+"],
  interfaceTypes:["LVDS","eDP","MIPI DSI","HDMI","VGA","DVI","DisplayPort","RGB","SPI","I2C","UART","HDBaseT","Parallel","Other"],
  resolutions:["160x128","240x128","320x240 (QVGA)","480x272","640x480 (VGA)","800x480","800x600 (SVGA)","1024x600","1024x768 (XGA)","1280x720 (HD)","1280x800","1280x1024 (SXGA)","1366x768","1440x900","1920x1080 (FHD)","1920x1200","2560x1440 (QHD)","3840x2160 (4K)"],
  touchTypes:["None","4-Wire Resistive","5-Wire Resistive","7-Wire Resistive","8-Wire Resistive","IR (Infrared)","SAW (Surface Acoustic Wave)","Projected Capacitive (PCAP)","Surface Capacitive","Multi-touch Resistive","Glass Surfaced Resistive"],
  constructions:["Glass-Film","Glass-Glass"],
  coverGlassMaterials:["Standard","Chemically Strengthened","Dragontrail","Gorilla Glass","Polycarbonate","Acrylic"],
  gloveInputs:["No Glove","Thin Glove","Thick Glove","Latex / Medical","Winter Glove"],
  touchInterfaces:["USB","I2C","USB/I2C","RS-232","SPI","UART"],
  noOfTouches:["Single","2-points","5-points or more"],
  touchControllerTypes:["Chip on Board","Chip on Flex","FFC only"],
  lcdControllerInputs:["HDMI","VGA","DVI","Display Port","USB","Ethernet","Composite","Other"],
  assemblyTypes:["Display Only","Sub-Assembly","Full Integration","Value Added","Enhancement Only","Touch Only"],
  enclosureTypes:["Open Frame","Fully Enclosed","Panel Mount","Custom"],
  enclosureMaterials:["Aluminum","Steel","Plastic"],
  finishes:["Plate","Paint","Power Coated","No Finish"],
  engineeringOptions:["Display Logic Engineering","Customer Engineering","Joint Engineering","N/A"],
  manufacturingOptions:["Display Logic Manufacturing","Customer Manufacturing","Contract Manufacturer","N/A"],
};

const SURFACE_TREATMENTS=[
  {id:"outdoor",label:"Outdoor"},{id:"uvStability",label:"UV Stability"},
  {id:"antiReflective",label:"AR (Anti-Reflective)"},{id:"borderMasking",label:"Border Masking"},
  {id:"antiGlare",label:"AG (Anti-Glare)"},{id:"hydrophobic",label:"Hydrophobic"},
  {id:"antiFingerprint",label:"AF (Anti-Fingerprint)"},
];

const COMPONENTS=[
  {id:"touchCable",label:"Touch Interface Cable"},{id:"touchController",label:"Touch Controller"},
  {id:"lcdDataCable",label:"LCD Data Cable"},{id:"backlightCable",label:"Backlight Power Cable"},
  {id:"lcdController",label:"LCD Controller"},{id:"powerSupply",label:"Power Supply"},
  {id:"perimeterTape",label:"Perimeter Tape Attach"},
];

const ACCEPTED={"application/pdf":"PDF","image/png":"Image","image/jpeg":"Image","image/jpg":"Image","image/tiff":"Image","image/webp":"Image","text/plain":"Text","text/csv":"CSV"};

async function callClaude(messages,system,maxTokens=1000){
  const res=await fetch("https://api.anthropic.com/v1/messages",{
    method:"POST",headers:{"Content-Type":"application/json"},
    body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:maxTokens,system,messages}),
  });
  const d=await res.json();
  if(d.error)throw new Error(d.error.message);
  return d.content?.[0]?.text||"";
}

function fileToBase64(file){
  return new Promise((res,rej)=>{
    const r=new FileReader();
    r.onload=()=>res(r.result.split(",")[1]);
    r.onerror=()=>rej(new Error("Read failed"));
    r.readAsDataURL(file);
  });
}

function buildPDFHTML(form,feasibility,narrative,components,surfaceTreatments,uploadedFiles){
  const date=new Date().toLocaleDateString("en-US",{year:"numeric",month:"long",day:"numeric"});
  const isIncomplete=feasibility?.overallStatus==="NEEDS_KEITH";
  const specRows=[
    ["Application",form.application],["Signal Source",form.signalSource],["Panel Type",form.panelType],
    ["Orientation",form.orientation],["Wide Viewing Angle",form.wideViewingAngle?"Yes":"No"],
    ["Diagonal",form.diagMin&&form.diagMax?`${form.diagMin}" to ${form.diagMax}"`:""],
    ["Interface Type",form.interfaceType],["Resolution (Primary)",form.resolution1],["Resolution (Alt)",form.resolution2],
    ["Operating Temp",form.operatingTempLow&&form.operatingTempHigh?`${form.operatingTempLow} to ${form.operatingTempHigh}`:""],
    ["Brightness",form.brightnessMin&&form.brightnessMax?`${form.brightnessMin} to ${form.brightnessMax}`:""],
    ["Backlight Life",form.backlightLife],["Outline mm",form.outlineMin&&form.outlineMax?`${form.outlineMin} to ${form.outlineMax} mm`:""],
    ["Active Area mm",form.activeAreaMin&&form.activeAreaMax?`${form.activeAreaMin} to ${form.activeAreaMax} mm`:""],
    ["Thickness mm",form.thicknessMin&&form.thicknessMax?`${form.thicknessMin} to ${form.thicknessMax} mm`:""],
    ["Product Lifecycle",form.productLifecycle?`${form.productLifecycle} years`:""],
    ["Touch Type",form.touchType],["Construction",form.construction],["Water Immunity",form.waterImmunity?"Yes":""],
    ["Cover Glass Dims",form.coverGlassW&&form.coverGlassH?`${form.coverGlassW} x ${form.coverGlassH} mm`:""],
    ["Cover Glass Material",form.coverGlassMaterial],["Cover Glass Thickness",form.coverGlassThickness?`${form.coverGlassThickness} mm`:""],
    ["Glove Input",form.gloveInput],["Touch Interface",form.touchInterface],
    ["No. of Touches",form.noOfTouches],["Touch Controller",form.touchControllerType],["Hardness",form.hardness?`${form.hardness}H`:""],
    ["LCD Controller Inputs",Object.keys(form.controllerInputs||{}).filter(k=>form.controllerInputs[k]).join(", ")||""],
    ["Assembly",form.assembly],["Enclosure",form.enclosure],["Enclosure Material",form.enclosureMaterial],
    ["Finish",form.finish],["Engineering",form.engineering],["Manufacturing",form.manufacturing],
  ].filter(([,v])=>v);

  const st=SURFACE_TREATMENTS.filter(s=>surfaceTreatments[s.id]).map(s=>s.label).join(", ")||"None";
  const cl=COMPONENTS.filter(c=>components[c.id]).map(c=>c.label).join(", ")||"None";

  const feasRows=feasibility?.lineItems?.map(item=>{
    const color=item.status==="MATCH"?"#10B981":item.status==="ALTERNATE"?"#F59E0B":item.status==="CONTACT_KEITH"?"#8B5CF6":"#EF4444";
    const icon=item.status==="MATCH"?"V":item.status==="ALTERNATE"?"~":item.status==="CONTACT_KEITH"?"?":"X";
    return`<tr><td style="padding:7px 10px;border-bottom:1px solid #172333;color:#EBF4FF;font-size:12px;">${item.spec}</td><td style="padding:7px 10px;border-bottom:1px solid #172333;color:#7A9BB8;font-size:11px;">${item.requested||""}</td><td style="padding:7px 10px;border-bottom:1px solid #172333;color:#7A9BB8;font-size:11px;">${item.dlCapability||""}</td><td style="padding:7px 10px;border-bottom:1px solid #172333;text-align:center;color:${color};font-weight:700;font-size:11px;">${icon} ${item.status.replace("_"," ")}</td><td style="padding:7px 10px;border-bottom:1px solid #172333;color:#7A9BB8;font-size:11px;">${item.note||""}</td></tr>`;
  }).join("")||"";

  return`<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Display Logic USA Specification</title></head>
<body style="background:#05080D;color:#EBF4FF;font-family:monospace;margin:0;padding:0;-webkit-print-color-adjust:exact;print-color-adjust:exact;">
<div style="max-width:860px;margin:0 auto;padding:36px 28px 60px;">
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:28px;padding-bottom:18px;border-bottom:2px solid #1F3348;">
  <div>
    <div style="display:flex;align-items:center;gap:10px;">
      <div style="width:34px;height:34px;background:#0EA5E9;border-radius:5px;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:13px;color:#05080D;">DL</div>
      <div><div style="font-size:16px;font-weight:900;letter-spacing:0.1em;">DISPLAY LOGIC USA</div><div style="font-size:9px;color:#7A9BB8;letter-spacing:0.1em;">HAUPPAUGE, NY - ITAR REGISTERED - 631-406-1922</div></div>
    </div>
  </div>
  <div style="text-align:right;">
    <div style="font-size:10px;color:#7A9BB8;">SPEC-${Date.now().toString(36).toUpperCase()}</div>
    <div style="font-size:10px;color:#7A9BB8;">${date}</div>
    <div style="margin-top:5px;padding:3px 10px;border-radius:3px;font-size:9px;font-weight:700;letter-spacing:0.1em;background:${isIncomplete?"#8B5CF620":"#10B98120"};border:1px solid ${isIncomplete?"#8B5CF660":"#10B98160"};color:${isIncomplete?"#8B5CF6":"#10B981"};">${isIncomplete?"PENDING KEITH REVIEW":"CUSTOMER APPROVED"}</div>
  </div>
</div>

<div style="margin-bottom:24px;">
  <div style="font-size:20px;font-weight:900;letter-spacing:0.04em;margin-bottom:5px;">LCD System Specification</div>
  <div style="font-size:12px;color:#7A9BB8;">For: <strong style="color:#EBF4FF;">${form.name||"Customer"}</strong>${form.company?" - "+form.company:""} - ${form.email||""}</div>
</div>

${feasibility?`
<div style="background:#0C1520;border:1px solid #1F3348;border-radius:8px;padding:18px 22px;margin-bottom:20px;display:flex;align-items:center;gap:20px;">
  <div style="text-align:center;flex-shrink:0;">
    <div style="font-size:44px;font-weight:900;color:${feasibility.feasibilityScore>=80?"#10B981":feasibility.feasibilityScore>=55?"#F59E0B":"#EF4444"};">${feasibility.feasibilityScore}</div>
    <div style="font-size:9px;color:#7A9BB8;letter-spacing:0.1em;">FEASIBILITY</div>
  </div>
  <div style="flex:1;">
    <div style="font-size:12px;font-weight:700;margin-bottom:5px;color:${feasibility.overallStatus==="COMPLETE"?"#10B981":feasibility.overallStatus==="PARTIAL"?"#F59E0B":"#8B5CF6"};">${feasibility.overallStatus==="COMPLETE"?"FULLY ACHIEVABLE":feasibility.overallStatus==="PARTIAL"?"ACHIEVABLE WITH ALTERNATES":"REQUIRES KEITH REVIEW"}</div>
    <div style="font-size:12px;color:#7A9BB8;line-height:1.6;">${feasibility.summary||""}</div>
  </div>
</div>`:""}

${narrative?`
<div style="background:#0C1520;border:1px solid #1F3348;border-radius:8px;padding:20px;margin-bottom:20px;">
  <div style="font-size:9px;font-weight:700;letter-spacing:0.14em;color:#0EA5E9;margin-bottom:12px;">TECHNICAL BUILD DESCRIPTION</div>
  <div style="font-size:12px;line-height:1.8;color:#B8D0E8;">${narrative.replace(/\n\n/g,"</p><p style='margin-top:10px;'>").replace(/^/,"<p>").replace(/$/,"</p>")}</div>
</div>`:""}

<div style="margin-bottom:20px;">
  <div style="font-size:9px;font-weight:700;letter-spacing:0.14em;color:#0EA5E9;margin-bottom:10px;">FULL SPECIFICATION</div>
  <table style="width:100%;border-collapse:collapse;background:#0C1520;border:1px solid #1F3348;border-radius:8px;overflow:hidden;">
    ${specRows.map(([k,v])=>`<tr><td style="padding:7px 14px;border-bottom:1px solid #172333;color:#7A9BB8;font-size:11px;width:38%;">${k}</td><td style="padding:7px 14px;border-bottom:1px solid #172333;color:#EBF4FF;font-size:12px;font-weight:600;">${v}</td></tr>`).join("")}
    <tr><td style="padding:7px 14px;border-bottom:1px solid #172333;color:#7A9BB8;font-size:11px;">Surface Treatments</td><td style="padding:7px 14px;border-bottom:1px solid #172333;color:#EBF4FF;font-size:12px;font-weight:600;">${st}</td></tr>
    <tr><td style="padding:7px 14px;color:#7A9BB8;font-size:11px;">Required Components</td><td style="padding:7px 14px;color:#EBF4FF;font-size:12px;font-weight:600;">${cl}</td></tr>
  </table>
</div>

${feasRows?`
<div style="margin-bottom:20px;">
  <div style="font-size:9px;font-weight:700;letter-spacing:0.14em;color:#0EA5E9;margin-bottom:10px;">CAPABILITY ANALYSIS</div>
  <table style="width:100%;border-collapse:collapse;background:#0C1520;border:1px solid #1F3348;border-radius:8px;overflow:hidden;">
    <tr style="background:#090E16;"><th style="padding:9px 10px;text-align:left;font-size:9px;letter-spacing:0.1em;color:#7A9BB8;">SPEC</th><th style="padding:9px 10px;text-align:left;font-size:9px;letter-spacing:0.1em;color:#7A9BB8;">REQUESTED</th><th style="padding:9px 10px;text-align:left;font-size:9px;letter-spacing:0.1em;color:#7A9BB8;">DL CAPABILITY</th><th style="padding:9px 10px;text-align:center;font-size:9px;letter-spacing:0.1em;color:#7A9BB8;">STATUS</th><th style="padding:9px 10px;text-align:left;font-size:9px;letter-spacing:0.1em;color:#7A9BB8;">NOTES</th></tr>
    ${feasRows}
  </table>
</div>`:""}

${feasibility?.flags?.length?`
<div style="background:#8B5CF610;border:1px solid #8B5CF640;border-radius:8px;padding:16px 20px;margin-bottom:20px;">
  <div style="font-size:9px;font-weight:700;letter-spacing:0.14em;color:#8B5CF6;margin-bottom:10px;">ITEMS FOR KEITH REVIEW</div>
  ${feasibility.flags.map(f=>`<div style="font-size:12px;color:#C4B5FD;margin-bottom:4px;">- ${f}</div>`).join("")}
</div>`:""}

${form.note?`
<div style="background:#0C1520;border:1px solid #1F3348;border-radius:8px;padding:16px 20px;margin-bottom:20px;">
  <div style="font-size:9px;font-weight:700;letter-spacing:0.14em;color:#0EA5E9;margin-bottom:8px;">CUSTOMER NOTES</div>
  <div style="font-size:12px;color:#7A9BB8;line-height:1.7;">${form.note}</div>
</div>`:""}

${uploadedFiles?.length?`
<div style="background:#0C1520;border:1px solid #1F3348;border-radius:8px;padding:16px 20px;margin-bottom:20px;">
  <div style="font-size:9px;font-weight:700;letter-spacing:0.14em;color:#0EA5E9;margin-bottom:8px;">REFERENCE FILES</div>
  ${uploadedFiles.map(f=>`<div style="font-size:12px;color:#7A9BB8;margin-bottom:3px;">[FILE] ${f.name} (${(f.size/1024).toFixed(1)} KB)</div>`).join("")}
</div>`:""}

<div style="border-top:1px solid #1F3348;padding-top:18px;display:flex;justify-content:space-between;align-items:flex-end;">
  <div><div style="font-size:12px;font-weight:700;color:#EBF4FF;margin-bottom:3px;">Display Logic USA</div><div style="font-size:11px;color:#7A9BB8;">631-406-1922 - sales@displaylogic.com - displaylogic.info</div><div style="font-size:11px;color:#7A9BB8;">Hauppauge, NY - ITAR Registered - 30+ Years</div></div>
  <div style="text-align:right;font-size:9px;color:#334E68;">AI Advisor Generated<br>${date}</div>
</div>
</div></body></html>`;
}

// ─── UI ATOMS ─────────────────────────────────────────────────────────────────
const F = "'IBM Plex Sans', system-ui, sans-serif";
const FM = "'IBM Plex Mono', monospace";
const baseInput = {background:C.surface,border:`1.5px solid ${C.border}`,borderRadius:8,padding:"11px 14px",color:C.text,fontSize:14,fontFamily:F,outline:"none",boxSizing:"border-box",transition:"border-color 0.15s",boxShadow:"0 1px 3px rgba(0,0,0,0.06)",width:"100%"};

const Sel=({label,options,value,onChange,required})=>(
  <div style={{marginBottom:20}}>
    {label&&<label style={{fontSize:12,fontWeight:600,color:C.textMid,marginBottom:7,display:"block",letterSpacing:"0.03em",fontFamily:F}}>{label}{required&&<span style={{color:C.red,marginLeft:3}}>*</span>}</label>}
    <select value={value||""} onChange={e=>onChange(e.target.value||null)}
      style={{...baseInput,appearance:"none",cursor:"pointer",paddingRight:36,color:value?C.text:C.textDim,borderColor:value?C.accent:C.border,
        backgroundImage:`url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='11' height='7' fill='none'%3E%3Cpath d='M1 1l4.5 5 4.5-5' stroke='%23475569' stroke-width='1.5' stroke-linecap='round'/%3E%3C/svg%3E")`,
        backgroundRepeat:"no-repeat",backgroundPosition:"right 12px center"}}>
      <option value="">Select...</option>
      {options.map(o=><option key={o} value={o}>{o}</option>)}
    </select>
  </div>
);

const DualSel=({label,options,vMin,vMax,onMin,onMax,required})=>(
  <div style={{marginBottom:20}}>
    <label style={{fontSize:12,fontWeight:600,color:C.textMid,marginBottom:7,display:"block",letterSpacing:"0.03em",fontFamily:F}}>{label}{required&&<span style={{color:C.red,marginLeft:3}}>*</span>}</label>
    <div style={{display:"flex",gap:8}}>
      {[["Min",vMin,onMin],["Max",vMax,onMax]].map(([ph,val,onCh])=>(
        <select key={ph} value={val||""} onChange={e=>onCh(e.target.value||null)}
          style={{...baseInput,flex:1,cursor:"pointer",color:val?C.text:C.textDim,fontSize:13,padding:"11px 10px"}}>
          <option value="">{ph}</option>
          {options.map(o=><option key={o} value={o}>{o}</option>)}
        </select>
      ))}
    </div>
  </div>
);

const Inp=({label,value,onChange,placeholder,unit,required,type="text"})=>(
  <div style={{marginBottom:20}}>
    {label&&<label style={{fontSize:12,fontWeight:600,color:C.textMid,marginBottom:7,display:"block",letterSpacing:"0.03em",fontFamily:F}}>{label}{required&&<span style={{color:C.red,marginLeft:3}}>*</span>}</label>}
    <div style={{display:"flex",alignItems:"center",gap:8}}>
      <input type={type} value={value||""} onChange={e=>onChange(e.target.value)} placeholder={placeholder||""}
        style={{...baseInput,flex:1}}/>
      {unit&&<span style={{fontSize:12,color:C.textMid,whiteSpace:"nowrap",fontFamily:FM}}>{unit}</span>}
    </div>
  </div>
);

const DualInp=({label,vMin,vMax,onMin,onMax,unit,required})=>(
  <div style={{marginBottom:20}}>
    {label&&<label style={{fontSize:12,fontWeight:600,color:C.textMid,marginBottom:7,display:"block",letterSpacing:"0.03em",fontFamily:F}}>{label}{required&&<span style={{color:C.red,marginLeft:3}}>*</span>}</label>}
    <div style={{display:"flex",alignItems:"center",gap:8}}>
      <input value={vMin||""} onChange={e=>onMin(e.target.value)} placeholder="Min" style={{...baseInput,flex:1}}/>
      <span style={{color:C.textDim,fontSize:14,flexShrink:0,fontFamily:FM}}>—</span>
      <input value={vMax||""} onChange={e=>onMax(e.target.value)} placeholder="Max" style={{...baseInput,flex:1}}/>
      {unit&&<span style={{fontSize:12,color:C.textMid,whiteSpace:"nowrap",fontFamily:FM}}>{unit}</span>}
    </div>
  </div>
);

const Chk=({label,checked,onChange})=>(
  <label style={{display:"flex",alignItems:"center",gap:10,cursor:"pointer",marginBottom:12,userSelect:"none"}}>
    <div onClick={()=>onChange(!checked)} style={{width:18,height:18,borderRadius:4,flexShrink:0,transition:"all 0.15s",border:`2px solid ${checked?C.accent:C.borderBright}`,background:checked?C.accent:"white",display:"flex",alignItems:"center",justifyContent:"center",boxShadow:checked?`0 0 0 3px ${C.accentGlow}`:"none"}}>
      {checked&&<svg width="10" height="8" viewBox="0 0 10 8" fill="none"><path d="M1 4l3 3 5-6" stroke="white" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>}
    </div>
    <span style={{fontSize:13,color:C.text,fontFamily:F}}>{label}</span>
  </label>
);

const SecHdr=({title,open,onToggle})=>(
  <div onClick={onToggle} style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"17px 22px",background:C.surface,cursor:"pointer",userSelect:"none",border:`1.5px solid ${open?C.accent:C.border}`,borderRadius:open?"10px 10px 0 0":10,marginBottom:open?0:10,boxShadow:open?"0 2px 8px rgba(27,79,216,0.08)":"0 1px 3px rgba(0,0,0,0.05)",transition:"all 0.15s"}}>
    <div style={{display:"flex",alignItems:"center",gap:12}}>
      <div style={{width:4,height:20,borderRadius:2,background:open?C.accent:C.borderBright,transition:"background 0.15s"}}/>
      <span style={{fontSize:14,fontWeight:700,color:C.text,fontFamily:F,letterSpacing:"0.01em"}}>{title}</span>
    </div>
    <div style={{width:28,height:28,borderRadius:7,background:open?C.accentGlow:C.bg,display:"flex",alignItems:"center",justifyContent:"center",transition:"all 0.15s"}}>
      <svg width="11" height="7" viewBox="0 0 11 7" style={{transform:open?"rotate(180deg)":"none",transition:"transform 0.2s"}}><path d="M1 1l4.5 5 4.5-5" stroke={open?C.accent:C.textMid} strokeWidth="1.5" strokeLinecap="round" fill="none"/></svg>
    </div>
  </div>
);

const SecBdy=({open,children})=>open?<div style={{padding:"24px 26px",background:C.surface,border:`1.5px solid ${C.accent}`,borderTop:"none",borderRadius:"0 0 10px 10px",marginBottom:10,boxShadow:"0 4px 12px rgba(27,79,216,0.05)"}}>{children}</div>:null;
const G2=({children})=><div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"0 36px"}}>{children}</div>;

// ─── FILE UPLOAD ──────────────────────────────────────────────────────────────
function FileUpload({onFilesAnalyzed,onFormUpdate}){
  const[dragging,setDragging]=useState(false);
  const[files,setFiles]=useState([]);
  const[analyzing,setAnalyzing]=useState(false);
  const[results,setResults]=useState([]);
  const ref=useRef(null);

  const handle=useCallback(async(newFiles)=>{
    const valid=Array.from(newFiles);
    if(!valid.length)return;
    setFiles(prev=>[...prev,...valid]);
    setAnalyzing(true);
    const out=[];
    for(const f of valid){
      try{
        const ft=ACCEPTED[f.type]||"Document";
        let content;
        if(ft==="Image"){
          const b64=await fileToBase64(f);
          content=[
            {type:"image",source:{type:"base64",media_type:f.type,data:b64}},
            {type:"text",text:`File: "${f.name}". Analyze for display specs. Extract dimensions, resolution, interface, brightness, temp, touch, power, part numbers. Respond:\n1) WHAT I FOUND: (list specs)\n2) DL CAPABILITY: (map to DL products)\n3) FORM PRE-FILL: (JSON with panelType, touchType, interfaceType, resolution1, operatingTempLow, operatingTempHigh, brightnessMin, brightnessMax, coverGlassMaterial, assembly)`}
          ];
        }else{
          const txt=await f.text().catch(()=>`[Binary: ${f.name}]`);
          content=`File: "${f.name}" (${ft})\n\n${txt.slice(0,6000)}\n\nAnalyze for display specs. Respond:\n1) WHAT I FOUND:\n2) DL CAPABILITY:\n3) FORM PRE-FILL: JSON with panelType, touchType, interfaceType, resolution1, operatingTempLow, operatingTempHigh, brightnessMin, brightnessMax, coverGlassMaterial, assembly`;
        }
        const reply=await callClaude([{role:"user",content}],DL_SYSTEM_PROMPT,1000);
        const jm=reply.match(/FORM PRE-FILL[^{]*({[\s\S]*?})/i);
        let pf={};
        if(jm){try{pf=JSON.parse(jm[1]);}catch{}}
        if(Object.keys(pf).length>0)onFormUpdate(pf);
        out.push({fileName:f.name,ft,analysis:reply,preFill:pf});
      }catch(e){
        out.push({fileName:f.name,ft:"Unknown",analysis:`Could not auto-analyze. Keith will review when you submit. (${e.message})`,preFill:{}});
      }
    }
    setResults(prev=>[...prev,...out]);
    setAnalyzing(false);
    onFilesAnalyzed(valid,out);
  },[onFilesAnalyzed,onFormUpdate]);

  return(
    <div style={{marginBottom:20}}>
      <div style={{fontSize:12,fontWeight:700,color:C.textMid,marginBottom:12,fontFamily:"'IBM Plex Sans',system-ui,sans-serif",letterSpacing:"0.02em"}}>Upload Reference Files — Schematics, Datasheets, Photos, RFQs, BOMs</div>
      <div onDragOver={e=>{e.preventDefault();setDragging(true);}} onDragLeave={()=>setDragging(false)} onDrop={e=>{e.preventDefault();setDragging(false);handle(e.dataTransfer.files);}} onClick={()=>ref.current?.click()}
        style={{border:`2px dashed ${dragging?C.accent:C.border}`,borderRadius:12,padding:"32px 20px",textAlign:"center",cursor:"pointer",background:dragging?C.accentGlow:C.surface,transition:"all 0.2s",marginBottom:12,boxShadow:"0 1px 4px rgba(0,0,0,0.05)"}}>
        <input ref={ref} type="file" multiple accept="*/*" style={{display:"none"}} onChange={e=>handle(e.target.files)}/>
        <div style={{fontSize:28,marginBottom:8}}>{analyzing?"⏳":dragging?"📂":"📁"}</div>
        <div style={{fontSize:15,fontWeight:600,color:dragging?C.accent:C.text,marginBottom:6,fontFamily:"'IBM Plex Sans',system-ui,sans-serif"}}>{analyzing?"Analyzing your files...":dragging?"Drop to analyze":"Drag & drop files here"}</div>
        <div style={{fontSize:12,color:C.textMid,fontFamily:"'IBM Plex Sans',system-ui,sans-serif"}}>PDF · DWG/DXF · PNG/JPG · DOCX · XLSX · CSV · Datasheet · Photo of existing display</div>
        {!analyzing&&<div style={{marginTop:12,fontSize:11,padding:"6px 16px",background:C.accentGlow,border:`1.5px solid ${C.accent}`,borderRadius:20,display:"inline-block",color:C.accent,fontWeight:600,fontFamily:"'IBM Plex Sans',system-ui,sans-serif"}}>or click to browse</div>}
      </div>
      {files.map((f,i)=>{
        const r=results[i];
        return(
          <div key={i} style={{background:C.surface,border:`1.5px solid ${r?C.accent:C.border}`,borderRadius:10,padding:"12px 16px",marginBottom:8,boxShadow:"0 1px 4px rgba(0,0,0,0.05)"}}>
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:r?8:0}}>
              <span style={{fontSize:14}}>📎</span>
              <span style={{fontSize:12,fontWeight:600,flex:1,color:C.text}}>{f.name}</span>
              <span style={{fontSize:10,color:C.textDim}}>{(f.size/1024).toFixed(1)} KB</span>
              {r?<span style={{fontSize:10,color:C.green,fontWeight:700}}>ANALYZED</span>:<span style={{fontSize:10,color:C.gold}}>Processing...</span>}
            </div>
            {r&&<div style={{fontSize:12,color:C.textMid,lineHeight:1.8,background:C.bg,borderRadius:8,padding:"12px 14px",maxHeight:180,overflow:"auto",whiteSpace:"pre-wrap",fontFamily:"'IBM Plex Sans',system-ui,sans-serif"}} dangerouslySetInnerHTML={{__html:r.analysis.replace(/\*\*(.*?)\*\*/g,`<strong style="color:${C.accent}">$1</strong>`).replace(/\n/g,"<br/>")}}/>}
            {r?.preFill&&Object.keys(r.preFill).length>0&&<div style={{marginTop:6,fontSize:10,color:C.green,padding:"3px 8px",background:C.greenGlow,borderRadius:4,display:"inline-block"}}>Auto-filled {Object.keys(r.preFill).length} form fields</div>}
          </div>
        );
      })}
    </div>
  );
}

// ─── AI ADVISOR ───────────────────────────────────────────────────────────────
function AIAdvisor({form,onFormUpdate,uploadedFiles}){
  const[msgs,setMsgs]=useState([{role:"assistant",text:"I am the Display Logic AI Display Advisor.\n\nUpload your files above and I will extract specs automatically. Or describe your application and I will configure the right system and tell you exactly what Display Logic can build.\n\nAsk me anything: ITAR requirements, optical bonding, xTremeLCD, touch technology tradeoffs, HDBaseT, Ynvisible electrochromic — I know the full product line."}]);
  const[input,setInput]=useState("");
  const[loading,setLoading]=useState(false);
  const endRef=useRef(null);
  const QUICK=["ITAR military display","Outdoor 1200 nit POE","Medical OLED gloved","Reworkable optical bonding","HDBaseT 100 meter","IoT zero power EPD","Gorilla Glass vs Dragontrail","PCAP vs resistive industrial","xTremeLCD specs","Ynvisible electrochromic"];

  useEffect(()=>{endRef.current?.scrollIntoView({behavior:"smooth"});},[msgs]);

  const send=async(text)=>{
    if(!text?.trim()||loading)return;
    const u=text.trim();
    setInput("");
    setMsgs(m=>[...m,{role:"user",text:u}]);
    setLoading(true);
    try{
      const ctx=form.application?`\n\n[Current config: App=${form.application}, Panel=${form.panelType}, Touch=${form.touchType||"not set"}, Interface=${form.interfaceType||"not set"}]`:"";
      const fctx=uploadedFiles?.length?`\n[${uploadedFiles.length} file(s) uploaded: ${uploadedFiles.map(f=>f.name).join(", ")}]`:"";
      const history=msgs.map(m=>({role:m.role==="user"?"user":"assistant",content:m.text}));
      const reply=await callClaude([...history,{role:"user",content:u+ctx+fctx}],DL_SYSTEM_PROMPT,1000);
      setMsgs(m=>[...m,{role:"assistant",text:reply}]);
    }catch{
      setMsgs(m=>[...m,{role:"assistant",text:"Connection issue. Offline answer: ITAR registered, patented reworkable optical bonding, xTremeLCD 1200 nit POE, 30-year manufacturer network, Ynvisible partnership. Call Keith: 631-406-1922."}]);
    }
    setLoading(false);
  };

  return(
    <div style={{background:C.surface,border:`1.5px solid ${C.border}`,borderRadius:12,marginBottom:16,boxShadow:"0 2px 8px rgba(0,0,0,0.06)"}}>
      <div style={{padding:"16px 22px",borderBottom:`1px solid ${C.border}`,display:"flex",alignItems:"center",gap:12,background:C.navBg,borderRadius:"10px 10px 0 0"}}>
        <div style={{width:9,height:9,borderRadius:"50%",background:"#22C55E",boxShadow:"0 0 10px rgba(34,197,94,0.6)"}}/>
        <span style={{fontSize:12,fontWeight:700,letterSpacing:"0.08em",color:"white",fontFamily:"'IBM Plex Sans',system-ui,sans-serif"}}>AI Display Advisor</span>
        <span style={{fontSize:11,color:"rgba(255,255,255,0.45)",fontFamily:"'IBM Plex Sans',system-ui,sans-serif"}}>— Trained on Display Logic full product line · Powered by Claude</span>
      </div>
      <div style={{padding:"20px 22px",minHeight:200,maxHeight:320,overflowY:"auto",display:"flex",flexDirection:"column",gap:16,background:"#FAFBFD"}}>
        {msgs.map((msg,i)=>(
          <div key={i} style={{display:"flex",gap:10,alignItems:"flex-start"}}>
            <div style={{width:30,height:30,borderRadius:"50%",flexShrink:0,display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:700,background:msg.role==="user"?C.accent:C.navBg,color:"white",marginTop:2,boxShadow:"0 1px 4px rgba(0,0,0,0.15)"}}>{msg.role==="user"?"YOU":"DL"}</div>
            <div style={{flex:1,fontSize:13,lineHeight:1.8,color:C.text,paddingTop:4,whiteSpace:"pre-wrap",fontFamily:"'IBM Plex Sans',system-ui,sans-serif"}} dangerouslySetInnerHTML={{__html:msg.text.replace(/\*\*(.*?)\*\*/g,`<strong style="color:${C.accent}">$1</strong>`).replace(/[✓]/g,`<span style="color:${C.green}">✓</span>`).replace(/[⚠]/g,`<span style="color:${C.gold}">⚠</span>`).replace(/[✗]/g,`<span style="color:${C.red}">✗</span>`)}}/>
          </div>
        ))}
        {loading&&<div style={{display:"flex",gap:10,alignItems:"flex-start"}}><div style={{width:26,height:26,borderRadius:"50%",background:C.border,display:"flex",alignItems:"center",justifyContent:"center",fontSize:9,color:C.textMid}}>DL</div><div style={{fontSize:12,color:C.textDim,paddingTop:4}}>analyzing...</div></div>}
        <div ref={endRef}/>
      </div>
      <div style={{padding:"12px 18px",borderTop:`1px solid ${C.border}`}}>
        <div style={{display:"flex",gap:5,flexWrap:"wrap",marginBottom:10}}>
          {QUICK.map(q=><button key={q} onClick={()=>send(q)} style={{background:C.surface,border:`1.5px solid ${C.border}`,color:C.textMid,padding:"5px 11px",borderRadius:6,cursor:"pointer",fontSize:11,fontFamily:"'IBM Plex Sans',system-ui,sans-serif",fontWeight:500,transition:"all 0.12s"}}>{q}</button>)}
        </div>
        <div style={{display:"flex",gap:8}}>
          <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==="Enter"&&!e.shiftKey&&send(input)} placeholder="Ask anything — ITAR, optical bonding, xTremeLCD, touch specs, HDBaseT..." style={{flex:1,background:C.surface,border:`1.5px solid ${C.border}`,borderRadius:8,padding:"11px 16px",color:C.text,fontSize:13,fontFamily:"'IBM Plex Sans',system-ui,sans-serif",outline:"none",boxShadow:"0 1px 3px rgba(0,0,0,0.06)"}}/>
          <button onClick={()=>send(input)} disabled={loading||!input.trim()} style={{background:C.accent,color:"white",border:"none",padding:"11px 22px",borderRadius:8,cursor:"pointer",fontWeight:700,fontFamily:"'IBM Plex Sans',system-ui,sans-serif",fontSize:13,opacity:loading||!input.trim()?0.45:1,boxShadow:"0 2px 8px rgba(27,79,216,0.25)",whiteSpace:"nowrap"}}>Send</button>
        </div>
      </div>
    </div>
  );
}

// ─── FEASIBILITY ──────────────────────────────────────────────────────────────
function FeasPanel({feasibility,loading}){
  if(loading)return<div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:10,padding:24,marginBottom:20,textAlign:"center"}}><div style={{fontSize:12,color:C.textMid}}>Running feasibility analysis...</div></div>;
  if(!feasibility)return null;
  const sc=feasibility.feasibilityScore>=80?C.green:feasibility.feasibilityScore>=55?C.gold:C.red;
  const stc={COMPLETE:C.green,PARTIAL:C.gold,NEEDS_KEITH:C.violet}[feasibility.overallStatus]||C.textMid;
  const stl={COMPLETE:"FULLY ACHIEVABLE",PARTIAL:"ACHIEVABLE WITH ALTERNATES",NEEDS_KEITH:"REQUIRES KEITH REVIEW"}[feasibility.overallStatus]||"";
  return(
    <div style={{background:C.surface,border:`1.5px solid ${stc}`,borderRadius:12,marginBottom:16,overflow:"hidden",boxShadow:"0 2px 12px rgba(0,0,0,0.07)"}}>
      <div style={{padding:"20px 26px",background:C.bg,borderBottom:`1px solid ${C.border}`,display:"flex",alignItems:"center",gap:24}}>
        <div style={{textAlign:"center",flexShrink:0}}>
          <div style={{fontSize:52,fontWeight:900,color:sc,lineHeight:1,fontFamily:"'IBM Plex Mono',monospace"}}>{feasibility.feasibilityScore}</div>
          <div style={{fontSize:10,color:C.textMid,letterSpacing:"0.08em",fontWeight:600,fontFamily:"'IBM Plex Sans',system-ui,sans-serif",marginTop:4}}>FEASIBILITY</div>
        </div>
        <div style={{flex:1}}>
          <div style={{fontSize:13,fontWeight:700,color:stc,letterSpacing:"0.02em",marginBottom:7,fontFamily:"'IBM Plex Sans',system-ui,sans-serif"}}>{feasibility.overallStatus==="COMPLETE"?"✓ ":feasibility.overallStatus==="PARTIAL"?"⚠ ":"⏳ "}{stl}</div>
          <div style={{fontSize:13,color:C.textMid,lineHeight:1.7,fontFamily:"'IBM Plex Sans',system-ui,sans-serif"}}>{feasibility.summary}</div>
        </div>
      </div>
      {feasibility.lineItems?.length>0&&(
        <div style={{padding:"18px 26px"}}>
          <div style={{fontSize:11,fontWeight:700,letterSpacing:"0.04em",color:C.textMid,marginBottom:14,fontFamily:"'IBM Plex Sans',system-ui,sans-serif"}}>Capability Breakdown</div>
          {feasibility.lineItems.map((item,i)=>{
            const ic={MATCH:C.green,ALTERNATE:C.gold,CONTACT_KEITH:C.violet,NOT_AVAILABLE:C.red}[item.status]||C.textMid;
            const ii={MATCH:"✓",ALTERNATE:"~",CONTACT_KEITH:"?",NOT_AVAILABLE:"✗"}[item.status]||"·";
            return(
              <div key={i} style={{display:"flex",alignItems:"flex-start",gap:12,padding:"8px 0",borderBottom:`1px solid ${C.border}`}}>
                <div style={{width:20,height:20,borderRadius:"50%",background:`${ic}20`,border:`1px solid ${ic}60`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,color:ic,flexShrink:0,marginTop:1}}>{ii}</div>
                <div style={{flex:1}}>
                  <div style={{fontSize:13,fontWeight:600,color:C.text,marginBottom:3,fontFamily:"'IBM Plex Sans',system-ui,sans-serif"}}>{item.spec}</div>
                  <div style={{fontSize:12,color:C.textMid,fontFamily:"'IBM Plex Sans',system-ui,sans-serif"}}>{item.requested} <span style={{color:C.textDim}}>→</span> <span style={{color:ic,fontWeight:600}}>{item.dlCapability}</span></div>
                  {item.note&&<div style={{fontSize:12,color:C.textMid,marginTop:3,fontStyle:"italic"}}>{item.note}</div>}
                </div>
              </div>
            );
          })}
        </div>
      )}
      {feasibility.dlStrengths?.length>0&&(
        <div style={{padding:"16px 26px",borderTop:`1px solid ${C.border}`,background:C.greenBg}}>
          <div style={{fontSize:11,fontWeight:700,letterSpacing:"0.04em",color:C.green,marginBottom:10,fontFamily:"'IBM Plex Sans',system-ui,sans-serif"}}>Display Logic Advantages for This Build</div>
          {feasibility.dlStrengths.map((s,i)=><div key={i} style={{fontSize:13,color:"#065F46",marginBottom:6,fontFamily:"'IBM Plex Sans',system-ui,sans-serif"}}>✓ {s}</div>)}
        </div>
      )}
      {feasibility.flags?.length>0&&(
        <div style={{padding:"16px 26px",borderTop:`1px solid ${C.border}`,background:C.violetBg}}>
          <div style={{fontSize:11,fontWeight:700,letterSpacing:"0.04em",color:C.violet,marginBottom:10,fontFamily:"'IBM Plex Sans',system-ui,sans-serif"}}>⏳ Items Flagged for Keith's Review</div>
          {feasibility.flags.map((f,i)=><div key={i} style={{fontSize:13,color:"#4C1D95",marginBottom:6,fontFamily:"'IBM Plex Sans',system-ui,sans-serif"}}>• {f}</div>)}
        </div>
      )}
    </div>
  );
}

// ─── MAIN ─────────────────────────────────────────────────────────────────────
export default function DisplayBuilder(){
  const[sec,setSec]=useState({lcd:true,touch:false,ctrl:false,asm:false});
  const[exploded,setExploded]=useState(false);
  const[showRenderer,setShowRenderer]=useState(true);
  const[comp,setComp]=useState(Object.fromEntries(COMPONENTS.map(c=>[c.id,false])));
  const[surf,setSurf]=useState({});
  const[uploadedFiles,setUploadedFiles]=useState([]);
  const[feasibility,setFeasibility]=useState(null);
  const[feasLoading,setFeasLoading]=useState(false);
  const[submitted,setSubmitted]=useState(false);
  const[genPDF,setGenPDF]=useState(false);
  const[form,setForm]=useState({
    application:null,signalSource:null,panelType:"TFT-LCD",orientation:"Landscape",wideViewingAngle:false,
    diagMin:null,diagMax:null,interfaceType:null,resolution1:null,resolution2:null,
    operatingTempLow:null,operatingTempHigh:null,brightnessMin:null,brightnessMax:null,backlightLife:null,
    outlineMin:null,outlineMax:null,activeAreaMin:null,activeAreaMax:null,thicknessMin:null,thicknessMax:null,productLifecycle:null,
    touchType:null,construction:null,waterImmunity:false,coverGlassW:null,coverGlassH:null,
    coverGlassMaterial:null,coverGlassThickness:null,gloveInput:null,touchInterface:null,
    hardness:null,noOfTouches:null,touchControllerType:null,controllerInputs:{},
    assembly:null,enclosure:null,enclosureMaterial:null,finish:null,engineering:null,manufacturing:null,note:null,
    name:null,email:null,company:null,phone:null,
  });

  const set=(k,v)=>setForm(f=>({...f,[k]:v}));
  const setMany=(obj)=>setForm(f=>({...f,...obj}));

  useEffect(()=>{
    if(!form.application||!form.panelType)return;
    const t=setTimeout(runFeas,1800);
    return()=>clearTimeout(t);
  },[form.application,form.panelType,form.touchType,form.interfaceType,form.brightnessMin,form.operatingTempLow]);

  const runFeas=async()=>{
    setFeasLoading(true);setFeasibility(null);
    try{
      const spec=JSON.stringify({application:form.application,panel:form.panelType,touch:form.touchType,interface:form.interfaceType,brightnessMin:form.brightnessMin,brightnessMax:form.brightnessMax,tempLow:form.operatingTempLow,tempHigh:form.operatingTempHigh,coverGlass:form.coverGlassMaterial,assembly:form.assembly,backlightLife:form.backlightLife,enclosure:form.enclosure});
      const raw=await callClaude([{role:"user",content:`Analyze this display spec against Display Logic USA capabilities. Return ONLY valid JSON, no markdown fences.\n\nSpec: ${spec}`}],FEASIBILITY_PROMPT+"\n\n"+DL_SYSTEM_PROMPT,1000);
      const parsed=JSON.parse(raw.replace(/```json|```/g,"").trim());
      setFeasibility(parsed);
    }catch{
      setFeasibility({overallStatus:"PARTIAL",feasibilityScore:72,summary:"Analysis unavailable — configuration looks achievable. Submit and Keith will confirm all specs.",lineItems:[],dlStrengths:["ITAR registered","30-year manufacturer network","Patented reworkable optical bonding"],flags:["Manual review recommended"]});
    }
    setFeasLoading(false);
  };

  const handleDownload=async()=>{
    setGenPDF(true);
    let nar="";
    try{
      nar=await callClaude([{role:"user",content:`Write a technical narrative for this display system:\nApp: ${form.application}, Panel: ${form.panelType}, Touch: ${form.touchType||"none"}, Interface: ${form.interfaceType||"TBD"}\nFeasibility: ${feasibility?.summary||"pending"}`}],PDF_NARRATIVE_PROMPT+"\n\n"+DL_SYSTEM_PROMPT,800);
    }catch{nar=`This display system has been configured through the Display Logic AI Advisor for a ${form.application||"custom"} application. The selected ${form.panelType} panel with ${form.touchType||"no touch"} represents an optimized solution.\n\nDisplay Logic USA's ITAR registration, 30-year manufacturer relationships, and patented reworkable optical bonding provide unique advantages for this build.\n\nPlease review all specifications and submit to Keith Morton for final pricing and feasibility confirmation.`;}
    const html=buildPDFHTML(form,feasibility,nar,comp,surf,uploadedFiles);
    const blob=new Blob([html],{type:"text/html"});
    const url=URL.createObjectURL(blob);
    const a=document.createElement("a");
    a.href=url;a.download=`DL_Spec_${(form.name||"Customer").replace(/\s/g,"_")}_${Date.now().toString(36).toUpperCase()}.html`;
    a.click();URL.revokeObjectURL(url);
    setGenPDF(false);
  };

  const isIncomplete=feasibility?.overallStatus==="NEEDS_KEITH";
  const canSubmit=form.name&&form.email&&form.application;

  if(submitted)return(
    <div style={{background:C.bg,minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'IBM Plex Sans',system-ui,sans-serif"}}>
      <div style={{maxWidth:560,width:"100%",padding:48,textAlign:"center",background:C.surface,borderRadius:20,boxShadow:"0 8px 40px rgba(0,0,0,0.10)",margin:24}}>
        <div style={{fontSize:54,marginBottom:14}}>{isIncomplete?"⏳":"✓"}</div>
        <h2 style={{fontSize:28,fontWeight:800,color:isIncomplete?C.violet:C.green,marginBottom:10,fontFamily:"'IBM Plex Sans',system-ui,sans-serif"}}>{isIncomplete?"Sent to Keith for Review":"Submitted to Keith"}</h2>
        <p style={{color:C.textMid,fontSize:14,lineHeight:1.8,marginBottom:28,fontFamily:"'IBM Plex Sans',system-ui,sans-serif"}}>{isIncomplete?"Your spec has items requiring Keith's expertise. He will review, confirm what is achievable, propose alternates, and respond with pricing.":"Complete display specification received by Keith. Expect a same-business-day response."}</p>
        <div style={{background:C.bg,border:`1.5px solid ${C.border}`,borderRadius:12,padding:22,marginBottom:28,textAlign:"left"}}>
          {[["Contact",`${form.name} - ${form.email}`],["Application",form.application],["Panel",form.panelType],["Touch",form.touchType||"Not specified"],["Status",isIncomplete?"PENDING KEITH REVIEW":"COMPLETE SPEC"],["Files",uploadedFiles.length>0?`${uploadedFiles.length} file(s) attached`:"None"]].map(([k,v])=>(
            <div key={k} style={{display:"flex",gap:16,padding:"6px 0",borderBottom:`1px solid ${C.border}`,fontSize:12}}>
              <span style={{color:C.textDim,width:90,flexShrink:0}}>{k}</span>
              <span style={{color:C.accent,fontWeight:700}}>{v}</span>
            </div>
          ))}
        </div>
        <div style={{display:"flex",gap:10,justifyContent:"center",flexWrap:"wrap"}}>
          <button onClick={()=>setSubmitted(false)} style={{background:C.surface,border:`1.5px solid ${C.border}`,color:C.textMid,padding:"12px 22px",borderRadius:8,cursor:"pointer",fontFamily:"'IBM Plex Sans',system-ui,sans-serif",fontSize:13,fontWeight:600}}>Build Another</button>
          <a href="tel:6314061922"><button style={{background:C.navBg,border:"none",color:"white",padding:"12px 22px",borderRadius:8,cursor:"pointer",fontFamily:"'IBM Plex Sans',system-ui,sans-serif",fontSize:13,fontWeight:600}}>Call Keith · 631-406-1922</button></a>
          <a href="mailto:sales@displaylogic.com"><button style={{background:C.accent,border:"none",color:"white",padding:"12px 22px",borderRadius:8,cursor:"pointer",fontFamily:"'IBM Plex Sans',system-ui,sans-serif",fontSize:13,fontWeight:600,boxShadow:"0 4px 14px rgba(27,79,216,0.3)"}}>Email Sales</button></a>
        </div>
      </div>
    </div>
  );

  const formWithSurf = {...form, surfaceTreatments: surf};

  return(
    <div style={{background:C.bg,minHeight:"100vh",fontFamily:"'IBM Plex Sans',system-ui,sans-serif",color:C.text,display:"flex",flexDirection:"column"}}>
      <div style={{background:C.navBg,borderBottom:`1px solid ${C.navBorder}`,padding:"0 28px",display:"flex",alignItems:"center",justifyContent:"space-between",height:56,position:"sticky",top:0,zIndex:100,boxShadow:"0 2px 12px rgba(0,0,0,0.18)"}}>
        <div style={{display:"flex",alignItems:"center",gap:14}}>
          <div style={{width:36,height:36,background:C.accent,borderRadius:8,display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,fontWeight:900,color:"white",letterSpacing:"-0.02em",boxShadow:"0 0 0 2px rgba(255,255,255,0.15)"}}>DL</div>
          <div>
            <div style={{fontSize:14,fontWeight:800,letterSpacing:"0.12em",color:"white",fontFamily:"'IBM Plex Sans',system-ui,sans-serif"}}>DISPLAY LOGIC USA</div>
            <div style={{fontSize:9.5,color:C.navDim,letterSpacing:"0.1em",fontFamily:"'IBM Plex Mono',monospace"}}>LCD SYSTEM BUILDER 3.0 · AI-POWERED · ITAR REGISTERED</div>
          </div>
        </div>
        <div style={{display:"flex",gap:20,alignItems:"center"}}>
          {["ITAR REGISTERED","30+ YRS","OPTICAL BONDING PATENT"].map(t=>(
            <span key={t} style={{fontSize:9,padding:"3px 8px",borderRadius:3,border:`1px solid ${C.navBorder}`,color:C.navDim,letterSpacing:"0.08em",fontFamily:"'IBM Plex Mono',monospace"}}>{t}</span>
          ))}
          <span style={{fontSize:12,color:"rgba(255,255,255,0.7)",fontFamily:"'IBM Plex Sans',system-ui,sans-serif"}}>631-406-1922</span>
        </div>
      </div>

      <div style={{display:"flex",flex:1,overflow:"hidden",height:"calc(100vh - 56px)"}}>

        {/* ── 3D RENDERER PANEL ── */}
        <div style={{width:showRenderer?"42%":"0",minWidth:showRenderer?"380px":"0",flexShrink:0,background:C.navBg,position:"sticky",top:56,height:"calc(100vh - 56px)",display:"flex",flexDirection:"column",transition:"width 0.3s ease",overflow:"hidden",borderRight:`1px solid ${C.navBorder}`}}>
          {showRenderer&&<>
            {/* Renderer Header */}
            <div style={{padding:"14px 18px",borderBottom:`1px solid ${C.navBorder}`,display:"flex",alignItems:"center",justifyContent:"space-between",flexShrink:0}}>
              <div>
                <div style={{fontSize:11,fontWeight:700,color:"white",letterSpacing:"0.06em",fontFamily:"'IBM Plex Mono',monospace"}}>LIVE 3D PREVIEW</div>
                <div style={{fontSize:10,color:C.navDim,marginTop:1,fontFamily:"'IBM Plex Mono',monospace"}}>Drag to rotate · Updates live</div>
              </div>
              <div style={{display:"flex",gap:6}}>
                <button onClick={()=>setExploded(e=>!e)} style={{padding:"5px 10px",borderRadius:5,border:`1px solid ${exploded?"#60A5FA":C.navBorder}`,background:exploded?"rgba(96,165,250,0.15)":"transparent",color:exploded?"#60A5FA":C.navDim,fontSize:10,fontWeight:600,cursor:"pointer",fontFamily:"'IBM Plex Mono',monospace",letterSpacing:"0.05em"}}>
                  {exploded?"ASSEMBLED":"EXPLODE"}
                </button>
              </div>
            </div>

            {/* Three.js Canvas */}
            <div style={{flex:1,position:"relative",overflow:"hidden"}}>
              <DisplayRenderer3D form={formWithSurf} exploded={exploded}/>
            </div>

            {/* Layer Legend */}
            <div style={{padding:"12px 18px",borderTop:`1px solid ${C.navBorder}`,flexShrink:0}}>
              <div style={{display:"flex",flexWrap:"wrap",gap:"6px 12px"}}>
                {[
                  {label:"LCD Panel",   color:"#1B6FD8", show:true},
                  {label:"Backlight",   color:"#FFF5B0", show:form.panelType!=="OLED"},
                  {label:"Touch",       color:"#90CAF9", show:form.touchType&&form.touchType!=="None"},
                  {label:"Cover Glass", color:"#B0D8F5", show:!!form.coverGlassMaterial},
                  {label:"Enclosure",   color:"#8A9BB0", show:!!form.enclosure&&form.enclosure!=="Display Only"},
                  {label:"AR Coating",  color:"#C0E8FF", show:!!surf.antiReflective},
                ].filter(l=>l.show).map(l=>(
                  <div key={l.label} style={{display:"flex",alignItems:"center",gap:5}}>
                    <div style={{width:8,height:8,borderRadius:2,background:l.color,flexShrink:0}}/>
                    <span style={{fontSize:9.5,color:C.navDim,fontFamily:"'IBM Plex Mono',monospace"}}>{l.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </>}
        </div>

        {/* ── FORM PANEL ── */}
        <div style={{flex:1,overflowY:"auto",padding:"28px 28px 100px"}}>
          <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:24}}>
            <div style={{fontSize:11,color:C.textMid,fontFamily:"'IBM Plex Mono',monospace"}}>Configure your display system below — the 3D preview updates in real time.</div>
            <button onClick={()=>setShowRenderer(r=>!r)} style={{padding:"6px 12px",borderRadius:6,border:`1px solid ${C.border}`,background:C.surface,color:C.textMid,fontSize:11,cursor:"pointer",fontFamily:"'IBM Plex Mono',monospace",whiteSpace:"nowrap"}}>
              {showRenderer?"Hide 3D":"Show 3D"}
            </button>
          </div>

        <FileUpload onFilesAnalyzed={(f,r)=>setUploadedFiles(f)} onFormUpdate={setMany}/>

        <AIAdvisor form={form} onFormUpdate={setMany} uploadedFiles={uploadedFiles}/>

        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"0 36px",background:C.surface,padding:"24px 26px",borderRadius:12,marginBottom:12,border:`1.5px solid ${C.border}`,boxShadow:"0 1px 4px rgba(0,0,0,0.06)"}}><Sel label="Application" required options={DATA.applications} value={form.application} onChange={v=>set("application",v)}/><Sel label="Signal Source" options={DATA.signalSources} value={form.signalSource} onChange={v=>set("signalSource",v)}/></div>

        <FeasPanel feasibility={feasibility} loading={feasLoading}/>

        <div style={{background:C.surface,border:`1.5px solid ${C.border}`,borderRadius:10,padding:20,marginBottom:12,boxShadow:"0 1px 4px rgba(0,0,0,0.06)"}}>
          <div style={{fontSize:11,fontWeight:700,letterSpacing:"0.06em",color:C.textMid,marginBottom:12,fontFamily:"'IBM Plex Sans',system-ui,sans-serif"}}>Required Components</div>
          <div style={{display:"flex",flexWrap:"wrap",gap:7}}>
            {COMPONENTS.map(c=><div key={c.id} onClick={()=>setComp(p=>({...p,[c.id]:!p[c.id]}))} style={{padding:"8px 14px",borderRadius:7,cursor:"pointer",fontSize:12,fontWeight:500,border:`1.5px solid ${comp[c.id]?C.accent:C.border}`,background:comp[c.id]?C.accentGlow:"white",color:comp[c.id]?C.accent:C.textMid,transition:"all 0.15s",boxShadow:comp[c.id]?"0 0 0 3px rgba(27,79,216,0.08)":"0 1px 2px rgba(0,0,0,0.05)"}}>{comp[c.id]?"✓ ":"○ "}{c.label}</div>)}
          </div>
        </div>

        <SecHdr title="LCD" open={sec.lcd} onToggle={()=>setSec(s=>({...s,lcd:!s.lcd}))}/>
        <SecBdy open={sec.lcd}>
          <G2>
            <div>
              <Sel label="Panel Type" required options={DATA.panelTypes} value={form.panelType} onChange={v=>set("panelType",v)}/>
              <Sel label="Orientation" required options={DATA.orientations} value={form.orientation} onChange={v=>set("orientation",v)}/>
              <Chk label="Wide Viewing Angle" checked={form.wideViewingAngle} onChange={v=>set("wideViewingAngle",v)}/>
              <div style={{height:10}}/>
              <DualInp label="Diagonal Min to Max" required vMin={form.diagMin} vMax={form.diagMax} onMin={v=>set("diagMin",v)} onMax={v=>set("diagMax",v)} unit="inches"/>
              <Sel label="Interface Type" options={DATA.interfaceTypes} value={form.interfaceType} onChange={v=>set("interfaceType",v)}/>
              <Sel label="Resolution opt 1" options={DATA.resolutions} value={form.resolution1} onChange={v=>set("resolution1",v)}/>
              <Sel label="Resolution opt 2" options={DATA.resolutions} value={form.resolution2} onChange={v=>set("resolution2",v)}/>
            </div>
            <div>
              <DualSel label="Operating Temp Low to High" required options={DATA.operatingTemps} vMin={form.operatingTempLow} vMax={form.operatingTempHigh} onMin={v=>set("operatingTempLow",v)} onMax={v=>set("operatingTempHigh",v)}/>
              <DualSel label="Brightness Min to Max" required options={DATA.brightness} vMin={form.brightnessMin} vMax={form.brightnessMax} onMin={v=>set("brightnessMin",v)} onMax={v=>set("brightnessMax",v)}/>
              <Sel label="Backlight Life min" required options={DATA.backlightLife} value={form.backlightLife} onChange={v=>set("backlightLife",v)}/>
              <DualInp label="Outline Min to Max" vMin={form.outlineMin} vMax={form.outlineMax} onMin={v=>set("outlineMin",v)} onMax={v=>set("outlineMax",v)} unit="mm"/>
              <DualInp label="Active Area Min to Max" vMin={form.activeAreaMin} vMax={form.activeAreaMax} onMin={v=>set("activeAreaMin",v)} onMax={v=>set("activeAreaMax",v)} unit="mm"/>
              <DualInp label="Thickness Min to Max" vMin={form.thicknessMin} vMax={form.thicknessMax} onMin={v=>set("thicknessMin",v)} onMax={v=>set("thicknessMax",v)} unit="mm"/>
              <Inp label="Product Lifecycle min" value={form.productLifecycle} onChange={v=>set("productLifecycle",v)} placeholder="e.g. 5" unit="years"/>
            </div>
          </G2>
        </SecBdy>

        <SecHdr title="Touch Screen / Cover Glass" open={sec.touch} onToggle={()=>setSec(s=>({...s,touch:!s.touch}))}/>
        <SecBdy open={sec.touch}>
          <G2>
            <div>
              <Sel label="Touch Type" required options={DATA.touchTypes} value={form.touchType} onChange={v=>set("touchType",v)}/>
              <Sel label="Construction" options={DATA.constructions} value={form.construction} onChange={v=>set("construction",v)}/>
              <Chk label="Water Immunity" checked={form.waterImmunity} onChange={v=>set("waterImmunity",v)}/>
              <div style={{height:8}}/>
              <DualInp label="Cover Glass Outer Dimensions" vMin={form.coverGlassW} vMax={form.coverGlassH} onMin={v=>set("coverGlassW",v)} onMax={v=>set("coverGlassH",v)} unit="W x H mm"/>
              <Sel label="Cover Glass Material" required options={DATA.coverGlassMaterials} value={form.coverGlassMaterial} onChange={v=>set("coverGlassMaterial",v)}/>
              <Inp label="Cover Glass Thickness" required value={form.coverGlassThickness} onChange={v=>set("coverGlassThickness",v)} placeholder="e.g. 2" unit="mm"/>
              <Sel label="Glove Input" options={DATA.gloveInputs} value={form.gloveInput} onChange={v=>set("gloveInput",v)}/>
              <Sel label="Interface" options={DATA.touchInterfaces} value={form.touchInterface} onChange={v=>set("touchInterface",v)}/>
            </div>
            <div>
              <div style={{marginBottom:14}}>
                <div style={{fontSize:10,fontWeight:700,letterSpacing:"0.12em",color:C.textMid,marginBottom:8}}>FRONT SURFACE TREATMENT</div>
                <div style={{border:`1.5px dashed ${C.border}`,borderRadius:10,padding:16,background:C.bg}}>
                  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:4}}>
                    {SURFACE_TREATMENTS.map(s=><Chk key={s.id} label={s.label} checked={!!surf[s.id]} onChange={()=>setSurf(p=>({...p,[s.id]:!p[s.id]}))}/>)}
                  </div>
                </div>
              </div>
              <Inp label="Hardness" value={form.hardness} onChange={v=>set("hardness",v)} placeholder="e.g. 7" unit="H Pencil"/>
              <Sel label="No. of Touches" options={DATA.noOfTouches} value={form.noOfTouches} onChange={v=>set("noOfTouches",v)}/>
              <Sel label="Touch Controller Type" options={DATA.touchControllerTypes} value={form.touchControllerType} onChange={v=>set("touchControllerType",v)}/>
            </div>
          </G2>
        </SecBdy>

        <SecHdr title="LCD Controller Input" open={sec.ctrl} onToggle={()=>setSec(s=>({...s,ctrl:!s.ctrl}))}/>
        <SecBdy open={sec.ctrl}>
          <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12}}>
            {DATA.lcdControllerInputs.map(inp=><Chk key={inp} label={inp} checked={!!form.controllerInputs[inp]} onChange={()=>setForm(f=>({...f,controllerInputs:{...f.controllerInputs,[inp]:!f.controllerInputs[inp]}}))}/>)}
          </div>
        </SecBdy>

        <SecHdr title="Assembly" open={sec.asm} onToggle={()=>setSec(s=>({...s,asm:!s.asm}))}/>
        <SecBdy open={sec.asm}>
          <G2>
            <div>
              <Sel label="Assembly" options={DATA.assemblyTypes} value={form.assembly} onChange={v=>set("assembly",v)}/>
              <Sel label="Enclosure Material" options={DATA.enclosureMaterials} value={form.enclosureMaterial} onChange={v=>set("enclosureMaterial",v)}/>
              <Sel label="Engineering" options={DATA.engineeringOptions} value={form.engineering} onChange={v=>set("engineering",v)}/>
            </div>
            <div>
              <Sel label="Enclosure" options={DATA.enclosureTypes} value={form.enclosure} onChange={v=>set("enclosure",v)}/>
              <Sel label="Finish" options={DATA.finishes} value={form.finish} onChange={v=>set("finish",v)}/>
              <Sel label="Manufacturing" options={DATA.manufacturingOptions} value={form.manufacturing} onChange={v=>set("manufacturing",v)}/>
            </div>
          </G2>
          <div style={{fontSize:10,fontWeight:700,letterSpacing:"0.12em",color:C.textMid,marginBottom:5}}>NOTE / ADDITIONAL REQUIREMENTS</div>
          <textarea value={form.note||""} onChange={e=>set("note",e.target.value)} placeholder="MIL-STD, IEC, IP rating, custom dims, lead time, connector type, custom branding..." style={{width:"100%",minHeight:100,background:C.bg,border:`1.5px solid ${C.border}`,borderRadius:8,padding:"12px 14px",color:C.text,fontSize:14,fontFamily:"'IBM Plex Sans',system-ui,sans-serif",resize:"vertical",boxSizing:"border-box",outline:"none",boxShadow:"0 1px 3px rgba(0,0,0,0.05)"}}/>
        </SecBdy>

        <div style={{background:C.surface,border:`1.5px solid ${C.border}`,borderRadius:12,padding:28,marginTop:14,boxShadow:"0 2px 12px rgba(0,0,0,0.07)"}}>
          <div style={{fontSize:16,fontWeight:700,marginBottom:6,color:C.text,fontFamily:"'IBM Plex Sans',system-ui,sans-serif"}}>Your Information</div>
          <div style={{fontSize:13,color:C.textMid,marginBottom:22,fontFamily:"'IBM Plex Sans',system-ui,sans-serif"}}>Required to generate your spec sheet and for Keith to follow up.</div>
          <G2>
            <Inp label="Name" required value={form.name} onChange={v=>set("name",v)} placeholder="Your name"/>
            <Inp label="Email" required value={form.email} onChange={v=>set("email",v)} placeholder="your@company.com" type="email"/>
            <Inp label="Company" value={form.company} onChange={v=>set("company",v)} placeholder="Company or Organization"/>
            <Inp label="Phone" value={form.phone} onChange={v=>set("phone",v)} placeholder="Optional"/>
          </G2>

          <div style={{display:"flex",gap:10,marginTop:8,flexWrap:"wrap"}}>
            <button onClick={handleDownload} disabled={!form.name||!form.email||genPDF} style={{flex:1,minWidth:200,padding:"14px 20px",borderRadius:9,border:`1.5px solid ${C.border}`,background:C.surface,color:!form.name||!form.email?C.textDim:C.text,cursor:!form.name||!form.email?"not-allowed":"pointer",fontFamily:"'IBM Plex Sans',system-ui,sans-serif",fontWeight:600,fontSize:14,boxShadow:"0 1px 4px rgba(0,0,0,0.07)",transition:"all 0.15s"}}>
              {genPDF?"⏳ Generating...":"↓ Download Spec Sheet"}
            </button>
            <button onClick={()=>canSubmit&&setSubmitted(true)} disabled={!canSubmit} style={{flex:2,minWidth:260,padding:"14px 20px",borderRadius:9,border:"none",background:canSubmit?(isIncomplete?C.violet:C.accent):"#CBD5E1",color:canSubmit?"white":C.textDim,cursor:canSubmit?"pointer":"not-allowed",fontFamily:"'IBM Plex Sans',system-ui,sans-serif",fontWeight:700,fontSize:14,boxShadow:canSubmit?`0 4px 16px ${isIncomplete?"rgba(91,33,182,0.35)":"rgba(27,79,216,0.35)"}`:"none",transition:"all 0.2s",letterSpacing:"0.01em"}}>
              {isIncomplete?"⏳ Send to Keith for Review":"→ Submit Spec to Keith"}
            </button>
          </div>

          {isIncomplete&&feasibility&&<div style={{marginTop:12,padding:"12px 16px",background:C.violetBg,border:`1.5px solid ${C.violet}`,borderRadius:8,fontSize:13,color:C.violet,fontFamily:"'IBM Plex Sans',system-ui,sans-serif"}}>
            This spec has {feasibility.flags?.length||"some"} item(s) requiring Keith's review. It will be marked PENDING REVIEW — Keith will confirm feasibility and propose alternates.
          </div>}

          {!canSubmit&&<div style={{marginTop:10,fontSize:12,color:C.textMid,textAlign:"center",fontFamily:"'IBM Plex Sans',system-ui,sans-serif"}}>
            Required: Application {form.application?"✓":"○"} · Name {form.name?"✓":"○"} · Email {form.email?"✓":"○"}
          </div>}
        </div>

        <div style={{marginTop:14,padding:"14px 20px",background:C.goldBg,border:`1.5px solid ${C.gold}`,borderRadius:10,fontSize:12,color:C.gold,textAlign:"center",fontFamily:"'IBM Plex Sans',system-ui,sans-serif",fontWeight:500}}>
          Every submission — complete specs and exploratory inquiries — is captured for Display Logic product development and marketing intelligence.
        </div>
        </div>{/* end form scroll area */}
      </div>{/* end split row */}
    </div>
  );
}
