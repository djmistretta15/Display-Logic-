import { useEffect, useRef, useState } from "react";

// ─── THREE.JS DISPLAY RENDERER ────────────────────────────────────────────────
// Renders a live 3D display assembly that updates as the user configures specs.
// Uses Three.js r128 loaded via CDN script tag.

const LAYER_Z = {
  enclosureBack:  -0.12,
  pcb:            -0.09,
  backlight:      -0.06,
  panel:           0.00,
  opticalBond:     0.04,
  touch:           0.07,
  coverGlass:      0.10,
  enclosureFront:  0.13,
};

const ASPECT_RATIOS = {
  "160x128":        160/128,
  "320x240 (QVGA)": 4/3,
  "480x272":        480/272,
  "640x480 (VGA)":  4/3,
  "800x480":        5/3,
  "800x600 (SVGA)": 4/3,
  "1024x600":       1024/600,
  "1024x768 (XGA)": 4/3,
  "1280x720 (HD)":  16/9,
  "1280x800":       16/10,
  "1280x1024 (SXGA)":5/4,
  "1366x768":       16/9,
  "1440x900":       16/10,
  "1920x1080 (FHD)":16/9,
  "1920x1200":      16/10,
  "2560x1440 (QHD)":16/9,
  "3840x2160 (4K)": 16/9,
  "default":        16/9,
};

function getAspect(res) {
  return ASPECT_RATIOS[res] || ASPECT_RATIOS["default"];
}

function getBrightnessColor(brightnessMin) {
  if (!brightnessMin) return { r:0.15, g:0.55, b:0.85, intensity:0.7 };
  const nit = parseInt(brightnessMin);
  if (nit >= 1200) return { r:1.0,  g:0.97, b:0.88, intensity:2.2 }; // xTremeLCD sunlight
  if (nit >= 800)  return { r:0.95, g:0.97, b:1.0,  intensity:1.6 };
  if (nit >= 500)  return { r:0.85, g:0.92, b:1.0,  intensity:1.1 };
  if (nit >= 300)  return { r:0.7,  g:0.82, b:1.0,  intensity:0.8 };
  return                  { r:0.5,  g:0.65, b:0.9,  intensity:0.5 };
}

function getPanelColor(panelType) {
  switch(panelType) {
    case "OLED":   return { r:0.05, g:0.05, b:0.12 }; // deep near-black
    case "EPD":    return { r:0.92, g:0.91, b:0.86 }; // e-paper cream
    case "STN-LCD":return { r:0.72, g:0.82, b:0.6  }; // greenish
    default:       return { r:0.08, g:0.14, b:0.22 }; // dark LCD off state
  }
}

export default function DisplayRenderer3D({ form, exploded, onLoad }) {
  const mountRef = useRef(null);
  const sceneRef = useRef(null);
  const rendererRef = useRef(null);
  const cameraRef = useRef(null);
  const meshesRef = useRef({});
  const animRef = useRef(null);
  const mouseRef = useRef({ isDown:false, lastX:0, lastY:0, rotX:0.18, rotY:-0.35 });
  const [loaded, setLoaded] = useState(false);
  const [threeLoaded, setThreeLoaded] = useState(!!window.THREE);

  // Load Three.js if not present
  useEffect(() => {
    if (window.THREE) { setThreeLoaded(true); return; }
    const script = document.createElement("script");
    script.src = "https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js";
    script.onload = () => { setThreeLoaded(true); };
    document.head.appendChild(script);
  }, []);

  // Init scene
  useEffect(() => {
    if (!threeLoaded || !mountRef.current) return;
    const THREE = window.THREE;
    const W = mountRef.current.clientWidth;
    const H = mountRef.current.clientHeight;

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias:true, alpha:true });
    renderer.setSize(W, H);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    mountRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // Camera
    const camera = new THREE.PerspectiveCamera(42, W/H, 0.01, 100);
    camera.position.set(0, 0.3, 3.2);
    camera.lookAt(0, 0, 0);
    cameraRef.current = camera;

    // Ambient
    const ambient = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambient);

    // Key light (upper left)
    const key = new THREE.DirectionalLight(0xfff5e0, 1.4);
    key.position.set(-3, 4, 3);
    key.castShadow = true;
    scene.add(key);

    // Fill light (right)
    const fill = new THREE.DirectionalLight(0xd0e8ff, 0.5);
    fill.position.set(4, 1, 2);
    scene.add(fill);

    // Rim light (back)
    const rim = new THREE.DirectionalLight(0x8899ff, 0.3);
    rim.position.set(0, -2, -3);
    scene.add(rim);

    // Environment sphere (subtle reflection source)
    const envGeo = new THREE.SphereGeometry(20, 16, 16);
    const envMat = new THREE.MeshBasicMaterial({
      color: 0xf0f4f8, side: THREE.BackSide, transparent:true, opacity:0.4
    });
    scene.add(new THREE.Mesh(envGeo, envMat));

    // Mouse orbit controls
    const canvas = renderer.domElement;
    const onDown = (e) => { mouseRef.current.isDown=true; mouseRef.current.lastX=e.clientX||e.touches?.[0]?.clientX; mouseRef.current.lastY=e.clientY||e.touches?.[0]?.clientY; };
    const onUp = () => { mouseRef.current.isDown=false; };
    const onMove = (e) => {
      if (!mouseRef.current.isDown) return;
      const x = e.clientX || e.touches?.[0]?.clientX;
      const y = e.clientY || e.touches?.[0]?.clientY;
      const dx = (x - mouseRef.current.lastX) * 0.008;
      const dy = (y - mouseRef.current.lastY) * 0.008;
      mouseRef.current.rotY += dx;
      mouseRef.current.rotX = Math.max(-0.8, Math.min(0.8, mouseRef.current.rotX + dy));
      mouseRef.current.lastX = x;
      mouseRef.current.lastY = y;
    };
    canvas.addEventListener("mousedown", onDown);
    canvas.addEventListener("touchstart", onDown);
    window.addEventListener("mouseup", onUp);
    window.addEventListener("touchend", onUp);
    canvas.addEventListener("mousemove", onMove);
    canvas.addEventListener("touchmove", onMove);

    setLoaded(true);
    if (onLoad) onLoad();

    // Animate
    const pivot = new THREE.Group();
    scene.add(pivot);
    sceneRef.current.pivot = pivot;

    const animate = () => {
      animRef.current = requestAnimationFrame(animate);
      // Auto-rotate slowly when not dragging
      if (!mouseRef.current.isDown) {
        mouseRef.current.rotY += 0.003;
      }
      pivot.rotation.y = mouseRef.current.rotY;
      pivot.rotation.x = mouseRef.current.rotX;
      renderer.render(scene, camera);
    };
    animate();

    // Resize
    const onResize = () => {
      if (!mountRef.current) return;
      const W2 = mountRef.current.clientWidth;
      const H2 = mountRef.current.clientHeight;
      camera.aspect = W2/H2;
      camera.updateProjectionMatrix();
      renderer.setSize(W2, H2);
    };
    window.addEventListener("resize", onResize);

    return () => {
      cancelAnimationFrame(animRef.current);
      canvas.removeEventListener("mousedown", onDown);
      canvas.removeEventListener("touchstart", onDown);
      window.removeEventListener("mouseup", onUp);
      window.removeEventListener("touchend", onUp);
      canvas.removeEventListener("mousemove", onMove);
      canvas.removeEventListener("touchmove", onMove);
      window.removeEventListener("resize", onResize);
      renderer.dispose();
      if (mountRef.current && renderer.domElement.parentNode === mountRef.current) {
        mountRef.current.removeChild(renderer.domElement);
      }
    };
  }, [threeLoaded]);

  // Rebuild meshes whenever form changes
  useEffect(() => {
    if (!loaded || !sceneRef.current?.pivot) return;
    const THREE = window.THREE;
    const pivot = sceneRef.current.pivot;

    // Clear old meshes
    Object.values(meshesRef.current).forEach(m => {
      pivot.remove(m);
      m.geometry?.dispose();
      m.material?.dispose();
    });
    meshesRef.current = {};

    const aspect = getAspect(form.resolution1);
    const W = aspect >= 1 ? 2.2 : 2.2 * aspect;
    const H = aspect >= 1 ? 2.2 / aspect : 2.2;
    const bColor = getBrightnessColor(form.brightnessMin);
    const pColor = getPanelColor(form.panelType);
    const hasTouch = form.touchType && form.touchType !== "None";
    const hasEnclosure = form.enclosure && form.enclosure !== "Display Only";
    const hasGlass = form.coverGlassMaterial && form.coverGlassMaterial !== "Standard";
    const isOLED = form.panelType === "OLED";
    const isPortrait = form.orientation === "Portrait" || form.orientation === "Reverse Portrait";
    const FW = isPortrait ? H : W;
    const FH = isPortrait ? W : H;

    const explodeScale = exploded ? 1 : 0;

    function addLayer(name, geoW, geoH, thick, zBase, color, opacity=1, roughness=0.3, metalness=0.0, emissive=null, emissiveIntensity=0) {
      const geo = new THREE.BoxGeometry(geoW, geoH, thick);
      const mat = new THREE.MeshStandardMaterial({
        color: new THREE.Color(color),
        transparent: opacity < 1,
        opacity,
        roughness,
        metalness,
        ...(emissive ? { emissive: new THREE.Color(emissive), emissiveIntensity } : {}),
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      const zOffset = explodeScale * (zBase - LAYER_Z.panel) * 4.5;
      mesh.position.set(0, 0, zBase + zOffset);
      pivot.add(mesh);
      meshesRef.current[name] = mesh;
      return mesh;
    }

    // ── ENCLOSURE BACK ──
    if (hasEnclosure) {
      const eMat = form.enclosureMaterial || "Aluminum";
      const eColor = eMat === "Steel" ? "#4A5568" : eMat === "Plastic" ? "#718096" : "#8A9BB0";
      const eRough = eMat === "Steel" ? 0.3 : eMat === "Plastic" ? 0.7 : 0.15;
      const eMetal = eMat === "Steel" ? 0.85 : eMat === "Plastic" ? 0.0 : 0.9;
      addLayer("encBack", FW+0.28, FH+0.28, 0.07, LAYER_Z.enclosureBack, eColor, 1, eRough, eMetal);
    }

    // ── PCB / DRIVER BOARD ──
    addLayer("pcb", FW-0.06, FH-0.06, 0.025, LAYER_Z.pcb, "#1A472A", 1, 0.9, 0.1,null,0);

    // ── BACKLIGHT (only for LCD, not OLED) ──
    if (!isOLED) {
      addLayer("backlight", FW-0.04, FH-0.04, 0.03, LAYER_Z.backlight, "#FFFFF0", 0.92, 0.1, 0.0,
        `rgb(${Math.round(bColor.r*255)},${Math.round(bColor.g*255)},${Math.round(bColor.b*255)})`,
        bColor.intensity * 0.4);
    }

    // ── LCD PANEL ──
    const panelEmissive = isOLED
      ? `rgb(${Math.round(pColor.r*255)},${Math.round(pColor.g*255)},${Math.round(pColor.b*255)})`
      : `rgb(${Math.round(bColor.r*255)},${Math.round(bColor.g*255)},${Math.round(bColor.b*255)})`;
    const panelEmissiveInt = isOLED ? 0 : bColor.intensity * 0.55;
    addLayer("panel", FW, FH, 0.04, LAYER_Z.panel,
      `rgb(${Math.round(pColor.r*255)},${Math.round(pColor.g*255)},${Math.round(pColor.b*255)})`,
      1, isOLED ? 0.05 : 0.12, 0.0, panelEmissive, panelEmissiveInt);

    // ── SCREEN CONTENT PLANE (simulated UI on panel face) ──
    const screenGeo = new THREE.PlaneGeometry(FW - 0.04, FH - 0.04);
    const screenCanvas = document.createElement("canvas");
    screenCanvas.width = 512; screenCanvas.height = Math.round(512 / aspect);
    const ctx = screenCanvas.getContext("2d");

    // Background gradient based on brightness
    const grad = ctx.createLinearGradient(0, 0, 512, screenCanvas.height);
    if (isOLED) {
      grad.addColorStop(0, "#000000");
      grad.addColorStop(1, "#0a0a1a");
    } else if (parseInt(form.brightnessMin) >= 1000) {
      grad.addColorStop(0, "#e8f4ff");
      grad.addColorStop(1, "#c5dff7");
    } else {
      grad.addColorStop(0, "#1a3a5c");
      grad.addColorStop(1, "#0d1f35");
    }
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 512, screenCanvas.height);

    // Simulated UI elements
    const textColor = isOLED ? "#00E5FF" : (parseInt(form.brightnessMin) >= 1000 ? "#1B4FD8" : "#4FC3F7");
    ctx.fillStyle = textColor;
    ctx.font = `bold ${Math.round(screenCanvas.height * 0.08)}px monospace`;
    ctx.textAlign = "center";
    ctx.fillText(form.application || "DISPLAY LOGIC", 256, screenCanvas.height * 0.22);
    ctx.font = `${Math.round(screenCanvas.height * 0.05)}px monospace`;
    ctx.fillStyle = isOLED ? "#ffffff80" : (parseInt(form.brightnessMin) >= 1000 ? "#47586890" : "#ffffff60");
    ctx.fillText(form.resolution1 || "1920×1080", 256, screenCanvas.height * 0.36);
    ctx.fillText(form.panelType || "TFT-LCD", 256, screenCanvas.height * 0.48);

    // Grid lines (HMI style)
    ctx.strokeStyle = `${textColor}20`;
    ctx.lineWidth = 1;
    for (let i = 1; i < 4; i++) {
      ctx.beginPath();
      ctx.moveTo(0, (screenCanvas.height/4)*i);
      ctx.lineTo(512, (screenCanvas.height/4)*i);
      ctx.stroke();
    }
    for (let i = 1; i < 4; i++) {
      ctx.beginPath();
      ctx.moveTo((512/4)*i, 0);
      ctx.lineTo((512/4)*i, screenCanvas.height);
      ctx.stroke();
    }

    const screenTex = new THREE.CanvasTexture(screenCanvas);
    const screenMat = new THREE.MeshStandardMaterial({ map:screenTex, roughness:0.05, metalness:0.0, transparent:true, opacity:0.95 });
    const screenMesh = new THREE.Mesh(screenGeo, screenMat);
    const zPos = LAYER_Z.panel + 0.021 + explodeScale*(LAYER_Z.panel - LAYER_Z.panel)*4.5;
    screenMesh.position.set(0, 0, zPos);
    pivot.add(screenMesh);
    meshesRef.current["screen"] = screenMesh;

    // ── OPTICAL BONDING LAYER ──
    if (hasTouch || hasGlass) {
      addLayer("optBond", FW+0.01, FH+0.01, 0.02, LAYER_Z.opticalBond, "#A8C8F0", 0.18, 0.02, 0.1, "#B8D8FF", 0.08);
    }

    // ── TOUCH LAYER ──
    if (hasTouch) {
      const tOpacity = form.touchType?.includes("Capacitive") ? 0.12 : 0.18;
      const tColor = form.touchType?.includes("Resistive") ? "#E8D5B0" : "#B8D8FF";
      addLayer("touch", FW+0.01, FH+0.01, 0.025, LAYER_Z.touch, tColor, tOpacity, 0.05, 0.2, tColor, 0.05);

      // Touch grid lines (PCAP visible grid)
      if (form.touchType?.includes("Capacitive")) {
        const lineGeo = new THREE.PlaneGeometry(FW, FH);
        const lineCanvas = document.createElement("canvas");
        lineCanvas.width = 256; lineCanvas.height = Math.round(256/aspect);
        const lctx = lineCanvas.getContext("2d");
        lctx.clearRect(0, 0, 256, lineCanvas.height);
        lctx.strokeStyle = "rgba(100,180,255,0.3)";
        lctx.lineWidth = 0.5;
        const step = 16;
        for (let x=0; x<256; x+=step) { lctx.beginPath(); lctx.moveTo(x,0); lctx.lineTo(x,lineCanvas.height); lctx.stroke(); }
        for (let y=0; y<lineCanvas.height; y+=step) { lctx.beginPath(); lctx.moveTo(0,y); lctx.lineTo(256,y); lctx.stroke(); }
        const lineTex = new THREE.CanvasTexture(lineCanvas);
        const lineMat = new THREE.MeshBasicMaterial({ map:lineTex, transparent:true, opacity:0.6, depthWrite:false });
        const lineMesh = new THREE.Mesh(lineGeo, lineMat);
        const lzPos = LAYER_Z.touch + 0.013 + explodeScale*(LAYER_Z.touch - LAYER_Z.panel)*4.5;
        lineMesh.position.set(0, 0, lzPos);
        pivot.add(lineMesh);
        meshesRef.current["touchGrid"] = lineMesh;
      }
    }

    // ── COVER GLASS ──
    if (hasGlass || hasTouch) {
      const glassRough = form.coverGlassMaterial?.includes("Gorilla") || form.coverGlassMaterial?.includes("Dragontrail") ? 0.02 : 0.05;
      const hasAR = form.surfaceTreatments?.antiReflective;
      const hasAG = form.surfaceTreatments?.antiGlare;
      const glassColor = hasAR ? "#D0E8FF" : hasAG ? "#E8EEF4" : "#C8DCEF";
      addLayer("glass", FW+0.02, FH+0.02, 0.03, LAYER_Z.coverGlass, glassColor, 0.15, glassRough, 0.3, "#E0F0FF", 0.04);
    }

    // ── ENCLOSURE FRONT BEZEL ──
    if (hasEnclosure) {
      const eMat = form.enclosureMaterial || "Aluminum";
      const eColor = eMat === "Steel" ? "#3D4A58" : eMat === "Plastic" ? "#5A6470" : "#78899A";
      const eRough = eMat === "Steel" ? 0.25 : eMat === "Plastic" ? 0.72 : 0.12;
      const eMetal = eMat === "Steel" ? 0.88 : eMat === "Plastic" ? 0.0 : 0.92;
      const bezelW = 0.14;

      // Build bezel as 4 pieces (top, bottom, left, right)
      [
        ["bezelTop",    FW+0.28, bezelW, 0, (FH+bezelW)/2],
        ["bezelBot",    FW+0.28, bezelW, 0, -(FH+bezelW)/2],
        ["bezelLeft",   bezelW,  FH, -((FW+bezelW)/2), 0],
        ["bezelRight",  bezelW,  FH, (FW+bezelW)/2, 0],
      ].forEach(([name, bw, bh, bx, by]) => {
        const bGeo = new THREE.BoxGeometry(bw, bh, 0.06);
        const bMat = new THREE.MeshStandardMaterial({ color:new THREE.Color(eColor), roughness:eRough, metalness:eMetal });
        const bMesh = new THREE.Mesh(bGeo, bMat);
        bMesh.castShadow = true;
        const zOff = explodeScale * (LAYER_Z.enclosureFront - LAYER_Z.panel) * 4.5;
        bMesh.position.set(bx, by, LAYER_Z.enclosureFront + zOff);
        pivot.add(bMesh);
        meshesRef.current[name] = bMesh;
      });
    }

    // ── SURFACE TREATMENT SHIMMER (AR coating) ──
    if (form.surfaceTreatments?.antiReflective) {
      const shimGeo = new THREE.PlaneGeometry(FW+0.03, FH+0.03);
      const shimMat = new THREE.MeshStandardMaterial({ color:"#AADDFF", transparent:true, opacity:0.06, roughness:0.0, metalness:0.8, depthWrite:false });
      const shimMesh = new THREE.Mesh(shimGeo, shimMat);
      const sz = LAYER_Z.coverGlass + 0.016 + explodeScale*(LAYER_Z.coverGlass - LAYER_Z.panel)*4.5;
      shimMesh.position.set(0, 0, sz);
      pivot.add(shimMesh);
      meshesRef.current["arShimmer"] = shimMesh;
    }

  }, [loaded, form, exploded]);

  if (!threeLoaded) return (
    <div style={{width:"100%",height:"100%",display:"flex",alignItems:"center",justifyContent:"center",color:"#94A3B8",fontSize:13}}>
      Loading 3D engine...
    </div>
  );

  return <div ref={mountRef} style={{width:"100%",height:"100%",cursor:"grab"}} />;
}
