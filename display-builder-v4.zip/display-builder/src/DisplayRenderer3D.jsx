import { useEffect, useRef, useState, forwardRef, useImperativeHandle } from "react";

// ─── LAYER REGISTRY ───────────────────────────────────────────────────────────
export const LAYER_MAP = {
  backPlate:   { z:-0.22, label:"Rear Housing",      color:"#607D8B", thick:"2.5mm",  desc:"CNC-machined structural enclosure" },
  pcb:         { z:-0.13, label:"Driver PCB",        color:"#2E7D32", thick:"1.6mm",  desc:"LCD timing controller & power regulation" },
  backlight:   { z:-0.055,label:"Backlight Unit",    color:"#FFF59D", thick:"4.0mm",  desc:"LED edge-lit DBEF diffuser array" },
  panel:       { z: 0.00, label:"LCD / OLED Panel",  color:"#1565C0", thick:"4.5mm",  desc:"Active matrix display cell" },
  opticalBond: { z: 0.07, label:"Optical Bond",      color:"#90CAF9", thick:"0.5mm",  desc:"DL patented reworkable OCA adhesive" },
  touch:       { z: 0.10, label:"Touch Sensor",      color:"#4FC3F7", thick:"1.2mm",  desc:"Projected capacitive ITO stack" },
  coverGlass:  { z: 0.145,label:"Cover Glass",       color:"#B3E5FC", thick:"3.0mm",  desc:"Chemically strengthened glass" },
  arCoating:   { z: 0.175,label:"AR / AG Coating",   color:"#E1F5FE", thick:"<0.1mm", desc:"Anti-reflective optical film" },
  bezel:       { z: 0.185,label:"Front Bezel",       color:"#78909C", thick:"5.0mm",  desc:"Structural frame & EMI shield" },
};

const ASPECTS = {
  "160x128":4/3,"320x240 (QVGA)":4/3,"480x272":480/272,"640x480 (VGA)":4/3,
  "800x480":5/3,"800x600 (SVGA)":4/3,"1024x600":1024/600,"1024x768 (XGA)":4/3,
  "1280x720 (HD)":16/9,"1280x800":16/10,"1280x1024 (SXGA)":5/4,"1366x768":16/9,
  "1440x900":16/10,"1920x1080 (FHD)":16/9,"1920x1200":16/10,
  "2560x1440 (QHD)":16/9,"3840x2160 (4K)":16/9,
};

// ─── SCREEN PAINTERS ──────────────────────────────────────────────────────────
function paintScreen(cv, app, panelType, brightnessMin) {
  const W = cv.width, H = cv.height;
  const ctx = cv.getContext("2d");
  const isOLED = panelType === "OLED";
  const isEPD  = panelType === "EPD";
  const bNit   = parseInt(brightnessMin) || 400;
  const isHigh = bNit >= 800;

  ctx.clearRect(0, 0, W, H);

  if (isEPD) { paintEPD(ctx, W, H); return; }

  // Base background
  const bg = ctx.createLinearGradient(0, 0, W, H);
  if (isOLED) {
    bg.addColorStop(0, "#000000"); bg.addColorStop(1, "#04001A");
  } else if (app?.match(/Military|Defense|ITAR/i)) {
    bg.addColorStop(0, "#000A02"); bg.addColorStop(1, "#001604");
  } else if (app?.match(/Medical|Diagnostic/i)) {
    bg.addColorStop(0, "#000820"); bg.addColorStop(1, "#001030");
  } else if (app?.match(/Industrial|HMI|Process/i)) {
    bg.addColorStop(0, "#0A0800"); bg.addColorStop(1, "#14100A");
  } else if (app?.match(/Outdoor|Kiosk|Transit|Wayfinding/i)) {
    if (isHigh) { bg.addColorStop(0, "#EBF4FF"); bg.addColorStop(1, "#C8DEF5"); }
    else        { bg.addColorStop(0, "#061830"); bg.addColorStop(1, "#0A2548"); }
  } else if (app?.match(/Marine|Aviation|Avionics/i)) {
    bg.addColorStop(0, "#000810"); bg.addColorStop(1, "#001520");
  } else if (app?.match(/Signage|Retail/i)) {
    bg.addColorStop(0, "#10001A"); bg.addColorStop(1, "#050008");
  } else {
    bg.addColorStop(0, "#050E20"); bg.addColorStop(1, "#08152E");
  }
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, W, H);

  // Dispatch to app-specific painter
  const a = app || "";
  if      (a.match(/Military|Defense/i))       paintMilitary(ctx, W, H, isOLED);
  else if (a.match(/Medical|Diagnostic/i))     paintMedical(ctx, W, H, isOLED);
  else if (a.match(/Industrial|HMI|Process/i)) paintIndustrial(ctx, W, H);
  else if (a.match(/Outdoor|Kiosk/i))          paintKiosk(ctx, W, H, isHigh);
  else if (a.match(/Transit|Wayfinding/i))     paintTransit(ctx, W, H);
  else if (a.match(/Signage|Retail/i))         paintSignage(ctx, W, H);
  else if (a.match(/Marine|Aviation|Avionics/i)) paintAvionics(ctx, W, H);
  else                                          paintDefault(ctx, W, H, isOLED, bNit);
}

function paintEPD(ctx, W, H) {
  ctx.fillStyle = "#F5F1E6"; ctx.fillRect(0, 0, W, H);
  // Subtle texture
  for (let i = 0; i < 4000; i++) {
    ctx.fillStyle = `rgba(0,0,0,${Math.random() * 0.04})`;
    ctx.fillRect(Math.random()*W, Math.random()*H, 1, 1);
  }
  ctx.fillStyle = "#111"; ctx.textAlign = "center";
  ctx.font = `bold ${H*.09}px 'IBM Plex Mono',monospace`;
  ctx.fillText("E-PAPER DISPLAY", W/2, H*.22);
  ctx.font = `${H*.045}px 'IBM Plex Mono',monospace`;
  ctx.fillStyle = "#555";
  ctx.fillText("Bistable · Zero-power hold", W/2, H*.36);
  ctx.fillText("Ynvisible Electrochromic", W/2, H*.46);
  // Waveform decoration
  ctx.strokeStyle = "#333"; ctx.lineWidth = 1.5;
  for (let i = 0; i < 4; i++) {
    ctx.beginPath();
    for (let x = 0; x <= W; x += 3) ctx.lineTo(x, H*.60 + Math.sin((x + i*60) / 28) * 9 + i * 14);
    ctx.stroke();
  }
}

function paintMilitary(ctx, W, H, isOLED) {
  const G = "#00FF41", D = "rgba(0,255,65,";
  // Subtle scanlines
  for (let y = 0; y < H; y += 3) {
    ctx.fillStyle = `rgba(0,0,0,${y%6===0?0.35:0.08})`;
    ctx.fillRect(0, y, W, 1.5);
  }
  // Dot grid
  ctx.fillStyle = D+"0.1)";
  for (let x = 0; x < W; x += 28) for (let y = 0; y < H; y += 28) {
    ctx.beginPath(); ctx.arc(x, y, 1, 0, Math.PI*2); ctx.fill();
  }
  // Ranging circles
  ctx.strokeStyle = D+"0.25)"; ctx.lineWidth = 0.8;
  [70, 120, 180, 250].forEach(r => {
    ctx.beginPath(); ctx.arc(W/2, H/2, r * (W/900), 0, Math.PI*2); ctx.stroke();
  });
  // Cardinal tick marks
  ctx.strokeStyle = G; ctx.lineWidth = 1.5;
  [0, Math.PI/2, Math.PI, Math.PI*3/2].forEach(a => {
    const R = 250*(W/900);
    ctx.beginPath();
    ctx.moveTo(W/2 + Math.cos(a)*R, H/2 + Math.sin(a)*R);
    ctx.lineTo(W/2 + Math.cos(a)*(R+14), H/2 + Math.sin(a)*(R+14));
    ctx.stroke();
  });
  // Crosshair
  ctx.strokeStyle = G; ctx.lineWidth = 1.2;
  ctx.setLineDash([4, 6]);
  ctx.beginPath(); ctx.moveTo(W/2-260, H/2); ctx.lineTo(W/2+260, H/2); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(W/2, H/2-180); ctx.lineTo(W/2, H/2+180); ctx.stroke();
  ctx.setLineDash([]);
  // Center pip
  ctx.strokeStyle = G; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.arc(W/2, H/2, 5, 0, Math.PI*2); ctx.stroke();
  // Data panels
  const lData = [["ALT","2,847 FT"],["HDG","247.3°"],["SPD","312 KTS"],["TEMP","-18°C"]];
  const rData = [["LOCK","ACQUIRED"],["CLASS","ITAR SEC"],["STATUS","ACTIVE"],["MODE","TRACK"]];
  ctx.font = `bold ${H*.048}px 'IBM Plex Mono',monospace`;
  ctx.fillStyle = G; ctx.textAlign = "left";
  lData.forEach(([k,v], i) => {
    ctx.fillStyle = D+"0.4)"; ctx.fillText(k, W*.03, H*(.12+i*.11));
    ctx.fillStyle = G; ctx.fillText(v, W*.03, H*(.12+i*.11+.06));
  });
  ctx.textAlign = "right";
  rData.forEach(([k,v], i) => {
    ctx.fillStyle = D+"0.4)"; ctx.fillText(k, W*.97, H*(.12+i*.11));
    ctx.fillStyle = i===1?"#FFCA28":G; ctx.fillText(v, W*.97, H*(.12+i*.11+.06));
  });
  // Bottom bar
  ctx.fillStyle = D+"0.12)"; ctx.fillRect(0, H*.87, W, H*.13);
  ctx.strokeStyle = D+"0.3)"; ctx.lineWidth=0.5; ctx.beginPath(); ctx.moveTo(0,H*.87); ctx.lineTo(W,H*.87); ctx.stroke();
  ctx.fillStyle = G; ctx.font = `${H*.038}px 'IBM Plex Mono',monospace`; ctx.textAlign = "center";
  ctx.fillText("DISPLAY LOGIC USA  ·  MIL-STD-810  ·  ITAR REGISTERED  ·  Hauppauge NY", W/2, H*.955);
}

function paintMedical(ctx, W, H, isOLED) {
  const BL = isOLED ? "#00BCD4" : "#2196F3";
  const WH = "rgba(255,255,255,";
  // Header bar
  ctx.fillStyle = `${BL}22`; ctx.fillRect(0, 0, W, H*.1);
  ctx.fillStyle = `${BL}40`; ctx.fillRect(0, H*.1-1.5, W, 1.5);
  ctx.fillStyle = "#E3F2FD"; ctx.font = `bold ${H*.052}px 'IBM Plex Sans',sans-serif`;
  ctx.textAlign = "left"; ctx.fillText("  PATIENT MONITOR", W*.01, H*.068);
  // Live badge
  ctx.fillStyle = "#FF5252"; ctx.beginPath(); ctx.arc(W*.93, H*.052, 5, 0, Math.PI*2); ctx.fill();
  ctx.fillStyle = "#FF5252"; ctx.font = `bold ${H*.042}px 'IBM Plex Sans',sans-serif`;
  ctx.textAlign = "right"; ctx.fillText("LIVE", W*.97, H*.068);

  // ECG Waveform
  const ecgY = H * .35;
  const ecgH = H * .12;
  // Grid
  ctx.strokeStyle = `${BL}18`; ctx.lineWidth = 0.5;
  for (let x = 0; x < W; x += W/20) { ctx.beginPath(); ctx.moveTo(x, H*.17); ctx.lineTo(x, H*.46); ctx.stroke(); }
  for (let y = H*.17; y < H*.46; y += H*.04) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); }
  // ECG trace
  const ecg = [0,0, .05,0, .06,-.04, .07,-.5, .08,.03, .09,1.0, .10,-.25, .11,0,
               .13,0, .14,.15, .15,.15, .16,0,  .18,0,
               .23,0, .24,-.04, .25,-.5, .26,.03, .27,1.0, .28,-.25, .29,0, .31,.15, .32,.15, .33,0,
               .38,0, .39,-.04, .40,-.5, .41,.03, .42,1.0, .43,-.25, .44,0, .46,.15, .47,.15, .48,0, 1,0];
  ctx.strokeStyle = BL; ctx.lineWidth = 2; ctx.shadowColor = BL; ctx.shadowBlur = 6;
  ctx.beginPath();
  for (let i = 0; i < ecg.length-1; i+=2) ctx.lineTo(W*(.01+ecg[i]*.98), ecgY+ecg[i+1]*ecgH);
  ctx.stroke(); ctx.shadowBlur = 0;

  // Vitals
  const vitals = [["HR","72","BPM","#EF5350"],["SpO₂","98","%","#26C6DA"],["BP","120/80","mmHg","#66BB6A"],["TEMP","37.1","°C","#FFA726"]];
  vitals.forEach(([lbl,val,unit,col], i) => {
    const vx = W*(.01+i*.25), vy = H*.49;
    ctx.fillStyle = `${col}15`; ctx.strokeStyle = `${col}30`; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.roundRect ? ctx.roundRect(vx, vy, W*.23, H*.24, 6) : ctx.rect(vx, vy, W*.23, H*.24);
    ctx.fill(); ctx.stroke();
    ctx.fillStyle = `${col}80`; ctx.font = `${H*.032}px 'IBM Plex Mono',monospace`; ctx.textAlign = "left";
    ctx.fillText(lbl, vx+W*.012, vy+H*.07);
    ctx.fillStyle = col; ctx.font = `bold ${H*.075}px 'IBM Plex Mono',monospace`;
    ctx.fillText(val, vx+W*.012, vy+H*.17);
    ctx.fillStyle = `${col}60`; ctx.font = `${H*.03}px 'IBM Plex Mono',monospace`;
    ctx.fillText(unit, vx+W*.012+ctx.measureText(val).width+4, vy+H*.16);
  });
  // Footer
  ctx.fillStyle = `${BL}10`; ctx.fillRect(0, H*.87, W, H*.13);
  ctx.fillStyle = `rgba(255,255,255,0.35)`; ctx.font = `${H*.032}px 'IBM Plex Mono',monospace`; ctx.textAlign = "center";
  ctx.fillText("DISPLAY LOGIC USA  ·  IEC 60601-1  ·  OPTICAL BONDING PATENT  ·  FDA 510(k) COMPATIBLE", W/2, H*.955);
}

function paintIndustrial(ctx, W, H) {
  const OR = "#FF6D00", AM = "#FFD600", GR = "#76FF03", RD = "#FF3D00";
  // Subtle grid
  ctx.strokeStyle = "rgba(255,109,0,0.07)"; ctx.lineWidth = 0.5;
  for (let x = 0; x < W; x += W/18) { ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,H); ctx.stroke(); }
  for (let y = 0; y < H; y += H/12) { ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(W,y); ctx.stroke(); }
  // Header
  ctx.fillStyle = "rgba(255,109,0,0.18)"; ctx.fillRect(0, 0, W, H*.1);
  ctx.fillStyle = OR; ctx.font = `bold ${H*.058}px 'IBM Plex Mono',monospace`;
  ctx.textAlign = "left"; ctx.fillText("PROCESS CONTROL  v4.2", W*.02, H*.073);
  ctx.fillStyle = GR; ctx.font = `${H*.04}px 'IBM Plex Mono',monospace`;
  ctx.textAlign = "right"; ctx.fillText("● SYS OK", W*.98, H*.073);

  // Three circular gauges
  [[W*.18,H*.42,"TEMP","847°C",0.78,GR],[W*.50,H*.42,"PRESSURE","142 PSI",0.55,AM],[W*.82,H*.42,"FLOW","2,340 L/h",0.88,RD]].forEach(([gx,gy,lbl,val,pct,col]) => {
    const R = H*.155;
    // Background arc
    ctx.strokeStyle = "rgba(255,255,255,0.08)"; ctx.lineWidth = 7;
    ctx.beginPath(); ctx.arc(gx, gy, R, Math.PI*.75, Math.PI*.25*5); ctx.stroke();
    // Colored arc
    ctx.strokeStyle = col; ctx.lineWidth = 7;
    ctx.lineCap = "round";
    ctx.shadowColor = col; ctx.shadowBlur = 12;
    ctx.beginPath(); ctx.arc(gx, gy, R, Math.PI*.75, Math.PI*.75 + pct*Math.PI*1.5); ctx.stroke();
    ctx.shadowBlur = 0; ctx.lineCap = "butt";
    // Tick marks
    ctx.strokeStyle = "rgba(255,255,255,0.2)"; ctx.lineWidth = 1;
    for (let t = 0; t <= 1; t += 0.1) {
      const a = Math.PI*.75 + t*Math.PI*1.5;
      ctx.beginPath();
      ctx.moveTo(gx+Math.cos(a)*(R-9), gy+Math.sin(a)*(R-9));
      ctx.lineTo(gx+Math.cos(a)*(R-16), gy+Math.sin(a)*(R-16));
      ctx.stroke();
    }
    // Value
    ctx.fillStyle = col; ctx.font = `bold ${H*.062}px 'IBM Plex Mono',monospace`; ctx.textAlign = "center";
    ctx.shadowColor = col; ctx.shadowBlur = 8;
    ctx.fillText(val, gx, gy+H*.022); ctx.shadowBlur=0;
    ctx.fillStyle = "rgba(255,255,255,0.5)"; ctx.font = `${H*.034}px sans-serif`;
    ctx.fillText(lbl, gx, gy+H*.082);
  });

  // Status strip
  ctx.fillStyle = "rgba(255,109,0,0.12)"; ctx.fillRect(0, H*.82, W, H*.08);
  [["PUMP A","RUN",GR],["VALVE 3","OPEN",AM],["HEATER","ON",OR],["ALARM","CLEAR",GR]].forEach(([k,v,c],i) => {
    const sx = W*(.04+i*.25);
    ctx.fillStyle="rgba(255,255,255,0.3)"; ctx.font=`${H*.03}px 'IBM Plex Mono',monospace`; ctx.textAlign="left";
    ctx.fillText(k, sx, H*.875);
    ctx.fillStyle=c; ctx.font=`bold ${H*.038}px 'IBM Plex Mono',monospace`;
    ctx.fillText(v, sx, H*.91);
  });
  ctx.fillStyle = "rgba(255,109,0,0.25)"; ctx.fillRect(0, H*.90, W, H*.1);
  ctx.fillStyle = OR; ctx.font = `${H*.032}px 'IBM Plex Mono',monospace`; ctx.textAlign = "center";
  ctx.fillText("DISPLAY LOGIC USA  ·  xTremeLCD IP-RATED  ·  HAUPPAUGE, NEW YORK", W/2, H*.955);
}

function paintKiosk(ctx, W, H, isHigh) {
  const C1 = isHigh ? "#1B4FD8" : "#0D2A6E";
  const TXT = isHigh ? "#FFFFFF" : "#E3F2FD";
  // Radial glow
  const rg = ctx.createRadialGradient(W/2, H*.4, 40, W/2, H*.4, W*.7);
  rg.addColorStop(0, isHigh?"rgba(27,79,216,0.3)":"rgba(27,79,216,0.2)");
  rg.addColorStop(1, "transparent");
  ctx.fillStyle = rg; ctx.fillRect(0, 0, W, H);
  // Header
  ctx.fillStyle = TXT; ctx.font = `black ${H*.12}px 'IBM Plex Sans',sans-serif`;
  ctx.textAlign = "center";
  ctx.shadowColor = "rgba(27,79,216,0.6)"; ctx.shadowBlur = 20;
  ctx.fillText("WELCOME", W/2, H*.22); ctx.shadowBlur = 0;
  ctx.font = `300 ${H*.048}px 'IBM Plex Sans',sans-serif`;
  ctx.fillStyle = `rgba(255,255,255,${isHigh?.7:.55})`;
  ctx.fillText("Touch to begin your experience", W/2, H*.32);
  // Buttons
  [["DIRECTIONS","→",W*.27],["INFORMATION","ℹ",W*.73]].forEach(([lbl,ic,bx]) => {
    const by = H*.52;
    const bw = W*.38, bh = H*.22;
    ctx.fillStyle = "rgba(255,255,255,0.08)";
    ctx.strokeStyle = "rgba(255,255,255,0.2)"; ctx.lineWidth = 1.5;
    ctx.beginPath();
    if(ctx.roundRect) ctx.roundRect(bx-bw/2, by-bh/2, bw, bh, 14);
    else ctx.rect(bx-bw/2, by-bh/2, bw, bh);
    ctx.fill(); ctx.stroke();
    ctx.fillStyle = TXT; ctx.font = `bold ${H*.058}px 'IBM Plex Sans',sans-serif`;
    ctx.fillText(lbl, bx, by+H*.012);
  });
  // Badge
  ctx.fillStyle = "rgba(255,214,0,0.15)"; ctx.fillRect(0, H*.86, W, H*.14);
  ctx.strokeStyle = "rgba(255,214,0,0.25)"; ctx.lineWidth=0.5; ctx.beginPath(); ctx.moveTo(0,H*.86); ctx.lineTo(W,H*.86); ctx.stroke();
  ctx.fillStyle = "#FFD600"; ctx.font = `bold ${H*.038}px 'IBM Plex Mono',monospace`; ctx.textAlign = "center";
  ctx.fillText("xTremeLCD 1200 NIT  ·  IEEE 802.3bt POE  ·  ITAR REGISTERED  ·  OUTDOOR RATED", W/2, H*.955);
}

function paintTransit(ctx, W, H) {
  ctx.fillStyle = "#0A0A0A"; ctx.fillRect(0, 0, W, H);
  // Yellow header
  const hh = H*.13;
  ctx.fillStyle = "#FFD600"; ctx.fillRect(0, 0, W, hh);
  ctx.fillStyle = "#000"; ctx.font = `black ${H*.082}px 'IBM Plex Sans',sans-serif`;
  ctx.textAlign = "left"; ctx.fillText("  NEXT DEPARTURES", 0, hh*.85);
  // Routes
  const routes = [
    ["A42","DOWNTOWN EXPRESS","2 MIN","#F44336"],
    ["B17","AIRPORT DIRECT",  "8 MIN","#4CAF50"],
    ["C09","UNIVERSITY",      "12 MIN","#2196F3"],
    ["A42","DOWNTOWN EXPRESS","17 MIN","#F44336"],
  ];
  routes.forEach(([rt,dest,time,col], i) => {
    const ry = hh + H*.045 + i * H*.195;
    ctx.fillStyle = i%2===0 ? "rgba(255,255,255,0.03)" : "transparent";
    ctx.fillRect(0, ry, W, H*.19);
    // Route bubble
    ctx.fillStyle = col;
    ctx.beginPath(); ctx.arc(W*.065, ry+H*.1, H*.065, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = "#000"; ctx.font = `black ${H*.052}px 'IBM Plex Sans',sans-serif`;
    ctx.textAlign = "center"; ctx.fillText(rt, W*.065, ry+H*.118);
    // Destination
    ctx.fillStyle = "#FFF"; ctx.font = `600 ${H*.054}px 'IBM Plex Sans',sans-serif`;
    ctx.textAlign = "left"; ctx.fillText(dest, W*.13, ry+H*.118);
    // Time
    ctx.fillStyle = col; ctx.font = `bold ${H*.054}px 'IBM Plex Mono',monospace`;
    ctx.textAlign = "right"; ctx.fillText(time, W*.97, ry+H*.118);
    // Divider
    ctx.strokeStyle = "rgba(255,255,255,0.06)"; ctx.lineWidth = 0.5;
    ctx.beginPath(); ctx.moveTo(0, ry+H*.19); ctx.lineTo(W, ry+H*.19); ctx.stroke();
  });
}

function paintSignage(ctx, W, H) {
  // Radial grid
  ctx.strokeStyle = "rgba(255,255,255,0.05)"; ctx.lineWidth = 0.6;
  for(let i=0;i<10;i++){ctx.beginPath();ctx.arc(W/2,H/2,H*(0.15+i*.08),0,Math.PI*2);ctx.stroke();}
  // Diagonal lines
  ctx.strokeStyle="rgba(255,255,255,0.03)";
  for(let i=-5;i<15;i++){ctx.beginPath();ctx.moveTo(i*W*.1,0);ctx.lineTo(i*W*.1+H,H);ctx.stroke();}
  // Logo glow
  const rg=ctx.createRadialGradient(W/2,H*.45,0,W/2,H*.45,W*.45);
  rg.addColorStop(0,"rgba(27,79,216,0.22)");rg.addColorStop(1,"transparent");
  ctx.fillStyle=rg;ctx.fillRect(0,0,W,H);
  // Main text
  ctx.fillStyle="#FFFFFF"; ctx.textAlign="center";
  ctx.font=`black ${H*.115}px 'IBM Plex Sans',sans-serif`;
  ctx.shadowColor="rgba(100,160,255,0.5)"; ctx.shadowBlur=30;
  ctx.fillText("DISPLAY LOGIC",W/2,H*.42); ctx.shadowBlur=0;
  ctx.font=`300 ${H*.048}px 'IBM Plex Sans',sans-serif`; ctx.fillStyle="rgba(255,255,255,0.55)";
  ctx.fillText("PRECISION DISPLAY SYSTEMS",W/2,H*.54);
  // Gradient line
  const lg=ctx.createLinearGradient(W*.05,0,W*.95,0);
  lg.addColorStop(0,"transparent");lg.addColorStop(0.3,"#1B4FD8");lg.addColorStop(0.7,"#1B4FD8");lg.addColorStop(1,"transparent");
  ctx.fillStyle=lg;ctx.fillRect(W*.05,H*.62,W*.9,1.5);
  ctx.fillStyle="rgba(255,255,255,0.35)";ctx.font=`${H*.036}px 'IBM Plex Mono',monospace`;
  ctx.fillText("HAUPPAUGE · NEW YORK · ITAR REGISTERED · 30+ YEARS",W/2,H*.74);
}

function paintAvionics(ctx, W, H) {
  const C="#00E5FF", Y="#FFD600";
  // Artificial horizon
  const cx=W*.5,cy=H*.42,R=H*.28;
  ctx.save(); ctx.beginPath(); ctx.arc(cx,cy,R,0,Math.PI*2); ctx.clip();
  // Sky / ground
  ctx.fillStyle="#1A3A6B"; ctx.fillRect(cx-R,cy-R,R*2,R);
  ctx.fillStyle="#4A2A12"; ctx.fillRect(cx-R,cy,R*2,R);
  // Pitch ladder
  ctx.strokeStyle="rgba(255,255,255,0.45)"; ctx.lineWidth=1;
  [-30,-20,-10,10,20,30].forEach(deg=>{
    const y=cy+deg*(R/60);
    const len=deg%20===0?R*.45:R*.25;
    ctx.beginPath();ctx.moveTo(cx-len,y);ctx.lineTo(cx+len,y);ctx.stroke();
    ctx.fillStyle="rgba(255,255,255,0.6)";ctx.font=`${H*.028}px monospace`;ctx.textAlign="right";
    ctx.fillText(Math.abs(deg),cx-len-4,y+4);
  });
  // Horizon line
  ctx.strokeStyle="#FFD600";ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(cx-R,cy);ctx.lineTo(cx+R,cy);ctx.stroke();
  ctx.restore();
  // ADI border
  ctx.strokeStyle=C;ctx.lineWidth=2;ctx.beginPath();ctx.arc(cx,cy,R,0,Math.PI*2);ctx.stroke();
  // Wing bars
  ctx.strokeStyle=Y;ctx.lineWidth=3;
  [[-1,1],[ 1,1]].forEach(([d]) => {
    ctx.beginPath();ctx.moveTo(cx+d*H*.06,cy);ctx.lineTo(cx+d*H*.18,cy);ctx.stroke();
    ctx.beginPath();ctx.moveTo(cx+d*H*.18,cy);ctx.lineTo(cx+d*H*.18,cy-H*.05);ctx.stroke();
  });
  ctx.fillStyle=Y;ctx.beginPath();ctx.arc(cx,cy,5,0,Math.PI*2);ctx.fill();
  // Data readouts
  ctx.fillStyle=C;ctx.font=`bold ${H*.055}px 'IBM Plex Mono',monospace`;ctx.textAlign="left";
  [["34,500 FT",H*.12],["MACH 0.82",H*.22],["V/S +200",H*.32]].forEach(([t,y])=>ctx.fillText(t,W*.03,y));
  ctx.textAlign="right";
  [["HDG 247°",H*.12],["IAS 480 KT",H*.22],["GS 1250 NM",H*.32]].forEach(([t,y])=>ctx.fillText(t,W*.97,y));
  ctx.fillStyle="rgba(0,229,255,0.12)";ctx.fillRect(0,H*.86,W,H*.14);
  ctx.strokeStyle="rgba(0,229,255,0.2)";ctx.lineWidth=0.5;ctx.beginPath();ctx.moveTo(0,H*.86);ctx.lineTo(W,H*.86);ctx.stroke();
  ctx.fillStyle=C;ctx.font=`${H*.035}px 'IBM Plex Mono',monospace`;ctx.textAlign="center";
  ctx.fillText("DO-160 CERTIFIED  ·  MIL-SPEC  ·  DISPLAY LOGIC USA",W/2,H*.952);
}

function paintDefault(ctx, W, H, isOLED, bNit) {
  const A = isOLED ? "#00E5FF" : bNit >= 1200 ? "#1B4FD8" : "#4FC3F7";
  // Subtle dot matrix
  ctx.fillStyle = `${A}12`;
  for(let x=0;x<W;x+=24) for(let y=0;y<H;y+=24) { ctx.beginPath();ctx.arc(x,y,1.2,0,Math.PI*2);ctx.fill(); }
  // Center glow
  const rg=ctx.createRadialGradient(W/2,H/2,20,W/2,H/2,W*.5);
  rg.addColorStop(0,`${A}20`);rg.addColorStop(1,"transparent");
  ctx.fillStyle=rg;ctx.fillRect(0,0,W,H);
  ctx.textAlign="center";
  ctx.font=`black ${H*.11}px 'IBM Plex Sans',sans-serif`;
  ctx.fillStyle=A; ctx.shadowColor=A; ctx.shadowBlur=20;
  ctx.fillText("DISPLAY LOGIC",W/2,H*.42); ctx.shadowBlur=0;
  ctx.font=`300 ${H*.045}px 'IBM Plex Sans',sans-serif`;
  ctx.fillStyle=`${A}70`;ctx.fillText("PRECISION DISPLAY SYSTEMS",W/2,H*.55);
  ctx.font=`${H*.03}px 'IBM Plex Mono',monospace`;
  ctx.fillStyle=`${A}40`;
  ctx.fillText("Hauppauge, NY  ·  ITAR Registered  ·  30+ Years",W/2,H*.68);
  if(bNit>=1200){
    ctx.fillStyle="rgba(255,245,100,0.2)";ctx.fillRect(0,H*.82,W,H*.18);
    ctx.fillStyle="#FFD600";ctx.font=`bold ${H*.042}px 'IBM Plex Mono',monospace`;
    ctx.fillText("xTremeLCD · 1200+ NIT · IEEE 802.3bt POE",W/2,H*.935);
  }
}

// ─── CHAMFERED BOX ────────────────────────────────────────────────────────────
function chamferedBox(THREE, w, h, d, c = 0.012) {
  c = Math.min(c, w * .045, h * .045);
  const shape = new THREE.Shape();
  shape.moveTo(-w/2+c,-h/2); shape.lineTo(w/2-c,-h/2);
  shape.quadraticCurveTo(w/2,-h/2,w/2,-h/2+c);
  shape.lineTo(w/2,h/2-c); shape.quadraticCurveTo(w/2,h/2,w/2-c,h/2);
  shape.lineTo(-w/2+c,h/2); shape.quadraticCurveTo(-w/2,h/2,-w/2,h/2-c);
  shape.lineTo(-w/2,-h/2+c); shape.quadraticCurveTo(-w/2,-h/2,-w/2+c,-h/2);
  const ext = { depth: d, bevelEnabled: true, bevelThickness: c*.5, bevelSize: c*.5, bevelSegments: 4 };
  const g = new THREE.ExtrudeGeometry(shape, ext);
  g.center(); return g;
}

// ─── BRUSHED METAL CANVAS ─────────────────────────────────────────────────────
function brushedMetal(color, direction = "h", size = 512) {
  const cv = document.createElement("canvas"); cv.width = size; cv.height = size;
  const ctx = cv.getContext("2d");
  const [r,g,b] = color.map(v => Math.round(v*255));
  ctx.fillStyle = `rgb(${r},${g},${b})`; ctx.fillRect(0,0,size,size);
  for (let i = 0; i < 2400; i++) {
    const pos = Math.random()*size;
    const alpha = Math.random()*.055 + .008;
    ctx.strokeStyle = Math.random()>.5 ? `rgba(255,255,255,${alpha})` : `rgba(0,0,0,${alpha})`;
    ctx.lineWidth = Math.random()*1.8+.2;
    ctx.beginPath();
    if (direction==="h") { ctx.moveTo(0,pos); ctx.lineTo(size,pos+(Math.random()*1.5-.75)); }
    else                 { ctx.moveTo(pos,0); ctx.lineTo(pos+(Math.random()*1.5-.75),size); }
    ctx.stroke();
  }
  // Edge shadow
  const vg=ctx.createLinearGradient(0,0,direction==="h"?0:size,direction==="h"?size:0);
  vg.addColorStop(0,"rgba(0,0,0,0.12)");vg.addColorStop(.5,"transparent");vg.addColorStop(1,"rgba(0,0,0,0.12)");
  ctx.fillStyle=vg; ctx.fillRect(0,0,size,size);
  return cv;
}

// ─── PCAP ITO DIAMOND PATTERN ─────────────────────────────────────────────────
function pcapTexture(asp) {
  const W = 512, H = Math.round(512/asp);
  const cv = document.createElement("canvas"); cv.width=W; cv.height=H;
  const ctx = cv.getContext("2d"); ctx.clearRect(0,0,W,H);
  const cell = 20;
  // Routing traces first (behind diamonds)
  ctx.strokeStyle="rgba(60,140,220,0.25)"; ctx.lineWidth=.6;
  for(let y=cell/2;y<H;y+=cell){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke();}
  for(let x=cell/2;x<W;x+=cell){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke();}
  // Diamond ITO electrodes
  for(let y=-cell;y<H+cell;y+=cell) for(let x=-cell;x<W+cell;x+=cell) {
    ctx.strokeStyle="rgba(100,180,255,0.5)"; ctx.lineWidth=.8;
    ctx.beginPath();
    ctx.moveTo(x+cell/2,y); ctx.lineTo(x+cell,y+cell/2);
    ctx.lineTo(x+cell/2,y+cell); ctx.lineTo(x,y+cell/2);
    ctx.closePath(); ctx.stroke();
    // Node pads
    ctx.fillStyle="rgba(140,210,255,0.7)";
    ctx.beginPath();ctx.arc(x+cell/2,y,2.2,0,Math.PI*2);ctx.fill();
    ctx.beginPath();ctx.arc(x,y+cell/2,1.4,0,Math.PI*2);ctx.fill();
  }
  return cv;
}

// ─── FLOATING LABEL ───────────────────────────────────────────────────────────
function FloatLabel({ name, desc, thick, sx, sy, side, visible }) {
  if (!visible) return null;
  const isR = side === "right";
  return (
    <div style={{ position:"absolute", left:sx, top:sy, transform:`translate(${isR?4:-4}px,-50%)`, pointerEvents:"none", display:"flex", alignItems:"center", gap:0 }}>
      {!isR && <div style={{flex:1,width:36,height:1,background:"rgba(96,165,250,0.4)",marginRight:6}}/>}
      <div style={{ background:"rgba(9,18,40,0.92)", border:"1px solid rgba(96,165,250,0.35)", borderRadius:6, padding:"5px 10px", backdropFilter:"blur(8px)", boxShadow:"0 4px 20px rgba(0,0,0,0.4)" }}>
        <div style={{ fontSize:10, fontWeight:700, color:"#90CAF9", fontFamily:"'IBM Plex Mono',monospace", letterSpacing:"0.07em", whiteSpace:"nowrap" }}>{name}</div>
        <div style={{ fontSize:8.5, color:"rgba(255,255,255,0.38)", fontFamily:"'IBM Plex Mono',monospace", whiteSpace:"nowrap", marginTop:1.5 }}>{thick} · {desc}</div>
      </div>
      {isR && <div style={{width:36,height:1,background:"rgba(96,165,250,0.4)",marginLeft:6}}/>}
    </div>
  );
}

// ─── RENDERER ─────────────────────────────────────────────────────────────────
const DisplayRenderer3D = forwardRef(function DisplayRenderer3D(
  { form, surf, exploded, autoRotate, focusLayer, highlightLayer, fullscreen, onFullscreenToggle },
  ref
) {
  const mountRef = useRef(null);
  const S = useRef({
    scene:null, renderer:null, camera:null, pivot:null, meshes:{},
    rotY:-0.42, rotX:0.22, targetRotY:-0.42, targetRotX:0.22,
    isDragging:false, lastX:0, lastY:0, animFrame:null,
    pulse:null, t:0,
  });
  const [ok, setOk] = useState(false);
  const [threeOk, setThreeOk] = useState(!!window.THREE);
  const [annots, setAnnots] = useState([]);
  const [showLabels, setShowLabels] = useState(false);
  const [annPositions, setAnnPositions] = useState([]);

  useImperativeHandle(ref, () => ({
    snapToLayer(key) {
      const L = LAYER_MAP[key]; if (!L) return;
      if (L.z > 0.08)       { S.current.targetRotY = -0.28; S.current.targetRotX = 0.08; }
      else if (L.z < -0.07) { S.current.targetRotY = Math.PI-.28; S.current.targetRotX = 0.08; }
      else                  { S.current.targetRotY = 0.02; S.current.targetRotX = 0.05; }
    },
    pulseLayer(key) { doPulse(key); },
  }));

  const doPulse = (key) => {
    const s = S.current; if (!window.THREE) return;
    if (s.pulse) { clearTimeout(s.pulse.timer); s.pulse.meshes.forEach(m=>{ if(m?.material){m.material.emissiveIntensity=0;} }); }
    const hits = Object.entries(s.meshes).filter(([k])=>k.toLowerCase().startsWith(key.toLowerCase())).map(([,m])=>m).filter(Boolean);
    hits.forEach(m=>{ if(m?.material){ m.material.emissive=new window.THREE.Color(.15,.45,1.0); m.material.emissiveIntensity=.8; }});
    const timer = setTimeout(()=>{ hits.forEach(m=>{ if(m?.material) m.material.emissiveIntensity=0; }); s.pulse=null; }, 2500);
    s.pulse = { meshes:hits, timer };
  };

  // Load Three.js
  useEffect(()=>{
    if(window.THREE){setThreeOk(true);return;}
    const el=document.createElement("script");
    el.src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js";
    el.onload=()=>setThreeOk(true);
    document.head.appendChild(el);
  },[]);

  // Init scene
  useEffect(()=>{
    if(!threeOk||!mountRef.current)return;
    const THREE=window.THREE, el=mountRef.current;
    const W=el.clientWidth||800, H=el.clientHeight||300;
    const renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,powerPreference:"high-performance"});
    renderer.setSize(W,H); renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
    renderer.toneMapping=THREE.ACESFilmicToneMapping; renderer.toneMappingExposure=1.3;
    renderer.shadowMap.enabled=true; renderer.shadowMap.type=THREE.PCFSoftShadowMap;
    el.appendChild(renderer.domElement);

    const scene=new THREE.Scene();
    const cam=new THREE.PerspectiveCamera(36,W/H,.01,100);
    cam.position.set(0,.7,5.8); cam.lookAt(0,0,0);

    // Lights — studio-quality 4-point setup
    scene.add(new THREE.AmbientLight(0xffffff,.40));

    const key=new THREE.DirectionalLight(0xFFFCF0,2.0);
    key.position.set(-4,7,5); key.castShadow=true;
    key.shadow.mapSize.set(2048,2048); key.shadow.bias=-0.0004;
    key.shadow.camera.near=.1; key.shadow.camera.far=40;
    key.shadow.camera.left=-8; key.shadow.camera.right=8;
    key.shadow.camera.top=8; key.shadow.camera.bottom=-8;
    scene.add(key);

    const fill=new THREE.DirectionalLight(0xC8DCFF,.55); fill.position.set(5,2,4); scene.add(fill);
    const rim=new THREE.DirectionalLight(0x4455BB,.28); rim.position.set(0,-5,-5); scene.add(rim);
    const top=new THREE.DirectionalLight(0xFFFFFF,.18); top.position.set(0,10,0); scene.add(top);

    // Ground shadow catcher
    const ground=new THREE.Mesh(new THREE.PlaneGeometry(24,24),new THREE.ShadowMaterial({opacity:.18}));
    ground.rotation.x=-Math.PI/2; ground.position.y=-2.5; ground.receiveShadow=true; scene.add(ground);

    // Environment map (studio)
    const ec=document.createElement("canvas"); ec.width=256; ec.height=128;
    const ectx=ec.getContext("2d");
    const eg=ectx.createLinearGradient(0,0,0,128);
    eg.addColorStop(0,"#C8DCF0"); eg.addColorStop(.45,"#EEF2F8"); eg.addColorStop(1,"#D8E4F0");
    ectx.fillStyle=eg; ectx.fillRect(0,0,256,128);
    const envTex=new THREE.CanvasTexture(ec);
    envTex.mapping=THREE.EquirectangularReflectionMapping;
    scene.environment=envTex;

    const pivot=new THREE.Group(); scene.add(pivot);
    Object.assign(S.current,{scene,renderer,camera:cam,pivot});

    // Input
    const down=(e)=>{S.current.isDragging=true;S.current.lastX=e.clientX??e.touches?.[0]?.clientX;S.current.lastY=e.clientY??e.touches?.[0]?.clientY;};
    const up=()=>{S.current.isDragging=false;};
    const move=(e)=>{
      if(!S.current.isDragging)return;
      const x=e.clientX??e.touches?.[0]?.clientX, y=e.clientY??e.touches?.[0]?.clientY;
      S.current.targetRotY+=(x-S.current.lastX)*.011;
      S.current.targetRotX=Math.max(-1.1,Math.min(1.1,S.current.targetRotX+(y-S.current.lastY)*.011));
      S.current.lastX=x; S.current.lastY=y;
    };
    renderer.domElement.addEventListener("mousedown",down);
    renderer.domElement.addEventListener("touchstart",down,{passive:true});
    window.addEventListener("mouseup",up); window.addEventListener("touchend",up);
    renderer.domElement.addEventListener("mousemove",move);
    renderer.domElement.addEventListener("touchmove",move,{passive:true});

    const animate=()=>{
      S.current.animFrame=requestAnimationFrame(animate);
      const s=S.current; s.t+=0.016;
      if(s.autoRotate&&!s.isDragging) s.targetRotY+=.005;
      s.rotY+=(s.targetRotY-s.rotY)*.055;
      s.rotX+=(s.targetRotX-s.rotX)*.055;
      pivot.rotation.y=s.rotY; pivot.rotation.x=s.rotX;
      // Pulse breathe
      if(s.pulse) { const pi=.35+Math.sin(s.t*3.5)*.35; s.pulse.meshes.forEach(m=>{if(m?.material)m.material.emissiveIntensity=pi;}); }
      renderer.render(scene,cam);
    };
    animate();

    const resize=()=>{
      if(!el)return; const W2=el.clientWidth,H2=el.clientHeight;
      if(!W2||!H2)return; cam.aspect=W2/H2; cam.updateProjectionMatrix(); renderer.setSize(W2,H2);
    };
    window.addEventListener("resize",resize);
    setOk(true);

    return()=>{
      cancelAnimationFrame(S.current.animFrame);
      window.removeEventListener("mouseup",up); window.removeEventListener("touchend",up); window.removeEventListener("resize",resize);
      renderer.dispose();
      if(el.contains(renderer.domElement))el.removeChild(renderer.domElement);
    };
  },[threeOk]);

  useEffect(()=>{ S.current.autoRotate=autoRotate; },[autoRotate]);
  useEffect(()=>{ if(focusLayer&&ref?.current) ref.current.snapToLayer(focusLayer); },[focusLayer]);
  useEffect(()=>{ if(highlightLayer) doPulse(highlightLayer); },[highlightLayer]);

  // Build geometry
  useEffect(()=>{
    if(!ok||!window.THREE)return;
    const THREE=window.THREE, s=S.current;

    // Dispose old
    Object.values(s.meshes).forEach(m=>{
      s.pivot.remove(m);
      m.geometry?.dispose();
      (Array.isArray(m.material)?m.material:[m.material]).forEach(mt=>mt?.dispose?.());
    });
    s.meshes={};

    const asp=ASPECTS[form?.resolution1]||16/9;
    const isPort=form?.orientation?.includes("Portrait");
    const bW=asp>=1?3.0:3.0*asp, bH=asp>=1?3.0/asp:3.0;
    const FW=isPort?bH:bW, FH=isPort?bW:bH;
    const ex=exploded?1:0, eS=7.0;
    const isOLED=form?.panelType==="OLED", isEPD=form?.panelType==="EPD";
    const hasTouch=form?.touchType&&form?.touchType!=="None";
    const hasPCAP=form?.touchType?.includes("Capacitive");
    const hasGlass=hasTouch||!!form?.coverGlassMaterial;
    const hasBond=hasTouch&&hasGlass;
    const hasEnc=form?.enclosure&&form?.enclosure!=="Display Only";
    const hasAR=!!surf?.antiReflective, hasAG=!!surf?.antiGlare;
    const eM=form?.enclosureMaterial||"Aluminum";
    const bNit=parseInt(form?.brightnessMin)||400;

    const glowC = bNit>=1200?[1.0,.97,.88]:bNit>=800?[.95,.97,1.0]:bNit>=500?[.80,.90,1.0]:[.60,.75,.95];
    const glowI = bNit>=1200?3.0:bNit>=800?1.9:bNit>=500?1.0:.5;

    const eColor = eM==="Steel"?[.22,.26,.30]:eM==="Plastic"?[.30,.33,.37]:[.44,.52,.60];
    const eRough = eM==="Steel"?.18:eM==="Plastic"?.74:.09;
    const eMetal = eM==="Steel"?.92:eM==="Plastic"?.0:.96;

    const mkStd=(col,rough,metal,extra={})=>new THREE.MeshStandardMaterial({color:new THREE.Color(...col),roughness:rough,metalness:metal,...extra});

    const addM=(key,geo,mat,zBase=0,ox=0,oy=0)=>{
      const m=new THREE.Mesh(geo,mat);
      m.castShadow=true; m.receiveShadow=true;
      const lz=LAYER_MAP[key]?.z??zBase;
      m.position.set(ox,oy,lz+ex*lz*eS);
      s.pivot.add(m); s.meshes[key]=m; return m;
    };

    // ── REAR HOUSING ──
    if(hasEnc){
      const brCv=brushedMetal(eColor.map(v=>v*.62), eM==="Steel"?"v":"h");
      const brTex=new THREE.CanvasTexture(brCv);
      addM("backPlate", chamferedBox(THREE,FW+.38,FH+.38,.055,.018),
        mkStd(eColor.map(v=>v*.60),eRough,eMetal,{map:brTex}), LAYER_MAP.backPlate.z);
    }

    // ── PCB ──
    addM("pcb", chamferedBox(THREE,FW-.14,FH-.14,.028,.007),
      mkStd([.06,.22,.09],.88,.06), LAYER_MAP.pcb.z);
    // IC components
    [[-.32,0,.22,.13],[.32,0,.22,.13],[0,.28,.15,.10],[0,-.28,.15,.10],[-FW*.28,FH*.22,.12,.08],[FW*.28,-FH*.22,.10,.07]].forEach(([cx,cy,cw,ch],i)=>{
      const m=new THREE.Mesh(new THREE.BoxGeometry(cw,ch,.024),mkStd([.10,.10,.13],.42,.68));
      m.position.set(cx,cy,LAYER_MAP.pcb.z+.025+ex*LAYER_MAP.pcb.z*eS);
      s.pivot.add(m); s.meshes[`ic${i}`]=m;
    });
    // Capacitors (small cylinders)
    [-FW*.22,-FW*.08,FW*.08,FW*.22].forEach((cx,i)=>{
      const geo=new THREE.CylinderGeometry(.03,.03,.06,10);
      const m=new THREE.Mesh(geo,mkStd([.1,.1,.5],.5,.2));
      m.position.set(cx,-FH*.3,LAYER_MAP.pcb.z+.05+ex*LAYER_MAP.pcb.z*eS);
      s.pivot.add(m); s.meshes[`cap${i}`]=m;
    });

    // ── BACKLIGHT ──
    if(!isOLED&&!isEPD){
      addM("backlight", chamferedBox(THREE,FW-.06,FH-.06,.038,.010),
        mkStd(glowC,.05,.0,{emissive:new THREE.Color(...glowC),emissiveIntensity:glowI*.4,transparent:true,opacity:.96}), LAYER_MAP.backlight.z);
    }

    // ── PANEL ──
    const pCol=isOLED?[.02,.02,.06]:isEPD?[.92,.91,.86]:[.05,.10,.18];
    addM("panel", chamferedBox(THREE,FW,FH,.044,.012),
      mkStd(pCol,isOLED?.03:.08,.0,{ emissive:new THREE.Color(...(isOLED?pCol:glowC)), emissiveIntensity:isOLED?0:glowI*.55 }),
      LAYER_MAP.panel.z);

    // ── SCREEN CANVAS ──
    const scW=Math.round(isPort?512/asp:512), scH=Math.round(isPort?512:512/asp);
    const scCv=document.createElement("canvas"); scCv.width=scW; scCv.height=scH;
    paintScreen(scCv, form?.application, form?.panelType, form?.brightnessMin);
    const scTex=new THREE.CanvasTexture(scCv);
    const scMat=mkStd(glowC,.02,.0,{map:scTex,transparent:true,opacity:.97,emissive:new THREE.Color(...glowC),emissiveIntensity:glowI*.15});
    const sc=new THREE.Mesh(new THREE.PlaneGeometry(FW-.05,FH-.05),scMat);
    sc.position.set(0,0,LAYER_MAP.panel.z+.023+ex*LAYER_MAP.panel.z*eS*.005);
    s.pivot.add(sc); s.meshes["screen"]=sc;

    // ── OPTICAL BOND ──
    if(hasBond){
      addM("opticalBond", chamferedBox(THREE,FW+.01,FH+.01,.020,.006),
        mkStd([.72,.86,.97],.04,.12,{transparent:true,opacity:.20,emissive:new THREE.Color(.5,.7,.95),emissiveIntensity:.04}),
        LAYER_MAP.opticalBond.z);
    }

    // ── TOUCH ──
    if(hasTouch){
      const tC=hasPCAP?[.40,.70,.95]:[.92,.82,.62];
      addM("touch", chamferedBox(THREE,FW+.01,FH+.01,.024,.007),
        mkStd(tC,.04,.18,{transparent:true,opacity:hasPCAP?.15:.22,emissive:new THREE.Color(...tC),emissiveIntensity:.05}),
        LAYER_MAP.touch.z);
      if(hasPCAP){
        const pcapCv=pcapTexture(asp);
        const pcapMesh=new THREE.Mesh(new THREE.PlaneGeometry(FW-.02,FH-.02),
          new THREE.MeshBasicMaterial({map:new THREE.CanvasTexture(pcapCv),transparent:true,opacity:.78,depthWrite:false}));
        pcapMesh.position.set(0,0,LAYER_MAP.touch.z+.013+ex*LAYER_MAP.touch.z*eS*.005);
        s.pivot.add(pcapMesh); s.meshes["pcapGrid"]=pcapMesh;
      }
    }

    // ── COVER GLASS — MeshPhysicalMaterial ──
    if(hasGlass){
      const isG=form?.coverGlassMaterial?.match(/Gorilla|Dragontrail/i);
      const isPoly=form?.coverGlassMaterial?.match(/Polycarbonate/i);
      const glassMat = THREE.MeshPhysicalMaterial ? new THREE.MeshPhysicalMaterial({
        color:new THREE.Color(hasAR?.82:.88,hasAR?.92:.95,1.0),
        transmission:isPoly?.65:.90, ior:isPoly?1.49:isG?1.52:1.51,
        thickness:isPoly?2.2:isG?3.0:2.5, roughness:hasAG?.42:isG?.018:.05,
        metalness:.0, transparent:true, opacity:hasAR?.16:.20,
        clearcoat:isG?1.0:.55, clearcoatRoughness:hasAG?.28:.04,
        reflectivity:.95, envMapIntensity:1.4,
      }) : mkStd([.84,.92,.98],hasAG?.4:.06,.1,{transparent:true,opacity:.20});
      addM("coverGlass", chamferedBox(THREE,FW+.04,FH+.04,.032,isG?.02:.013), glassMat, LAYER_MAP.coverGlass.z);
    }

    // ── AR SHIMMER ──
    if(hasAR||hasAG){
      const shim=new THREE.Mesh(new THREE.PlaneGeometry(FW+.05,FH+.05),
        new THREE.MeshStandardMaterial({color:new THREE.Color(.7,.88,1),roughness:.0,metalness:.95,transparent:true,opacity:.06,depthWrite:false}));
      shim.position.set(0,0,LAYER_MAP.arCoating.z+ex*LAYER_MAP.arCoating.z*eS*.005);
      s.pivot.add(shim); s.meshes["arCoating"]=shim;
    }

    // ── BEZEL ──
    if(hasEnc){
      const brCv2=brushedMetal(eColor,eM==="Steel"?"v":"h");
      const brTex2=new THREE.CanvasTexture(brCv2);
      const bW2=.20;
      [
        ["bezelT",FW+bW2*2,bW2,0,(FH+bW2)/2],
        ["bezelB",FW+bW2*2,bW2,0,-(FH+bW2)/2],
        ["bezelL",bW2,FH,-(FW+bW2)/2,0],
        ["bezelR",bW2,FH,(FW+bW2)/2,0],
      ].forEach(([key,bw,bh,bx,by])=>{
        const m=new THREE.Mesh(chamferedBox(THREE,bw,bh,.068,.012),
          mkStd(eColor,eRough,eMetal,{map:brTex2}));
        m.castShadow=true;
        m.position.set(bx,by,LAYER_MAP.bezel.z+ex*LAYER_MAP.bezel.z*eS);
        s.pivot.add(m); s.meshes[key]=m;
      });
      // Port cutouts on right bezel
      const ports=Object.keys(form?.controllerInputs||{}).filter(k=>form?.controllerInputs?.[k]);
      ports.slice(0,5).forEach((p,i)=>{
        const pm=new THREE.Mesh(new THREE.BoxGeometry(.030,.020,.08),
          mkStd([.01,.01,.01],.95,.0));
        pm.position.set((FW+bW2)/2+.001, FH*.3-i*.1, LAYER_MAP.bezel.z+ex*LAYER_MAP.bezel.z*eS);
        s.pivot.add(pm); s.meshes[`port${i}`]=pm;
      });
    }

    // Build annotation data
    const activeAnnots=Object.entries(LAYER_MAP).filter(([k])=>{
      if(k==="backPlate"||k==="bezel") return hasEnc;
      if(k==="backlight") return !isOLED&&!isEPD;
      if(k==="opticalBond") return hasBond;
      if(k==="touch") return hasTouch;
      if(k==="coverGlass") return hasGlass;
      if(k==="arCoating") return hasAR||hasAG;
      return true;
    }).map(([k,v])=>({key:k,...v}));
    setAnnots(activeAnnots);

  },[ok,form,surf,exploded]);

  // Project annotation world positions to screen
  useEffect(()=>{
    if(!annots.length||!ok)return;
    const update=()=>{
      const s=S.current;
      if(!window.THREE||!s.pivot||!s.camera||!mountRef.current)return;
      const THREE=window.THREE, el=mountRef.current;
      const W=el.clientWidth, H=el.clientHeight;
      const pos=annots.map((a,i)=>{
        const v=new THREE.Vector3(0,0,a.z+(exploded?a.z*7.0:0));
        v.applyMatrix4(s.pivot.matrixWorld); v.project(s.camera);
        const sx=(v.x*.5+.5)*W, sy=(-.5*v.y+.5)*H;
        return {...a, sx, sy, side:i%2===0?"right":"left"};
      });
      setAnnPositions(pos);
    };
    const id=setInterval(update,60);
    return()=>clearInterval(id);
  },[annots,ok,exploded]);

  if(!threeOk) return <div style={{width:"100%",height:"100%",display:"flex",alignItems:"center",justifyContent:"center",color:"#64748B",fontSize:12,fontFamily:"'IBM Plex Mono',monospace"}}>LOADING 3D ENGINE...</div>;

  return (
    <div style={{position:"relative",width:"100%",height:"100%",overflow:"hidden"}}>
      <div ref={mountRef} style={{width:"100%",height:"100%",cursor:"grab"}}/>

      {/* Controls overlay — top right */}
      <div style={{position:"absolute",top:10,right:10,display:"flex",gap:5,alignItems:"center"}}>
        {exploded&&(
          <button onClick={()=>setShowLabels(l=>!l)} style={{
            padding:"4px 10px",borderRadius:5,fontSize:9.5,fontWeight:700,cursor:"pointer",
            fontFamily:"'IBM Plex Mono',monospace",letterSpacing:"0.07em",
            border:`1px solid ${showLabels?"rgba(96,165,250,.45)":"rgba(255,255,255,.12)"}`,
            background:showLabels?"rgba(96,165,250,.15)":"rgba(0,0,0,.5)",
            color:showLabels?"#60A5FA":"rgba(255,255,255,.45)",
            backdropFilter:"blur(6px)",
          }}>LABELS</button>
        )}
        <button onClick={onFullscreenToggle} style={{
          width:30,height:30,borderRadius:6,border:"1px solid rgba(255,255,255,.12)",
          background:"rgba(0,0,0,.5)",color:"rgba(255,255,255,.55)",cursor:"pointer",
          display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,
          backdropFilter:"blur(6px)",
        }} title={fullscreen?"Exit fullscreen":"Fullscreen"}>
          {fullscreen?"⊠":"⊡"}
        </button>
      </div>

      {/* Floating annotations */}
      {showLabels && exploded && annPositions.map(a=>(
        <FloatLabel key={a.key} name={a.label} desc={a.desc} thick={a.thick} sx={a.sx} sy={a.sy} side={a.side} visible/>
      ))}

      {/* Layer legend — bottom left */}
      <div style={{position:"absolute",bottom:10,left:12,display:"flex",flexWrap:"wrap",gap:"4px 14px",maxWidth:"65%",pointerEvents:"none"}}>
        {annots.map(a=>(
          <div key={a.key} style={{display:"flex",alignItems:"center",gap:5}}>
            <div style={{width:7,height:7,borderRadius:2,background:a.color,flexShrink:0,boxShadow:`0 0 5px ${a.color}70`}}/>
            <span style={{fontSize:9,color:"rgba(255,255,255,0.42)",fontFamily:"'IBM Plex Mono',monospace"}}>{a.label}</span>
          </div>
        ))}
      </div>

      {/* xTremeLCD badge */}
      {parseInt(form?.brightnessMin)>=1200&&(
        <div style={{position:"absolute",bottom:10,right:10,padding:"3px 9px",borderRadius:4,
          background:"rgba(255,245,80,0.12)",border:"1px solid rgba(255,245,80,0.35)",
          fontSize:9,color:"#FFF176",fontFamily:"'IBM Plex Mono',monospace",fontWeight:700,
          letterSpacing:"0.08em",pointerEvents:"none",backdropFilter:"blur(4px)"}}>
          xTremeLCD 1200+ NIT
        </div>
      )}
    </div>
  );
});

export default DisplayRenderer3D;
