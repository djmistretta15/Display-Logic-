import { useEffect, useRef, useState, useImperativeHandle, forwardRef } from "react";

// ─── LAYER DEFINITIONS ────────────────────────────────────────────────────────
export const LAYER_MAP = {
  panel:        { z: 0.00, label: "LCD Panel",      color: "#1B6FD8" },
  backlight:    { z:-0.05, label: "Backlight",       color: "#FFF176" },
  pcb:          { z:-0.09, label: "Driver PCB",      color: "#2E7D32" },
  opticalBond:  { z: 0.04, label: "Optical Bond",    color: "#90CAF9" },
  touch:        { z: 0.07, label: "Touch Layer",     color: "#64B5F6" },
  coverGlass:   { z: 0.11, label: "Cover Glass",     color: "#B3E5FC" },
  arCoating:    { z: 0.13, label: "AR Coating",      color: "#E1F5FE" },
  bezel:        { z: 0.14, label: "Bezel",           color: "#90A4AE" },
};

const ASPECT_MAP = {
  "160x128": 160/128, "320x240 (QVGA)": 4/3, "480x272": 480/272,
  "640x480 (VGA)": 4/3, "800x480": 5/3, "800x600 (SVGA)": 4/3,
  "1024x600": 1024/600, "1024x768 (XGA)": 4/3, "1280x720 (HD)": 16/9,
  "1280x800": 16/10, "1280x1024 (SXGA)": 5/4, "1366x768": 16/9,
  "1440x900": 16/10, "1920x1080 (FHD)": 16/9, "1920x1200": 16/10,
  "2560x1440 (QHD)": 16/9, "3840x2160 (4K)": 16/9,
};

function getAspect(res) { return ASPECT_MAP[res] || 16/9; }

function brightnessToGlow(b) {
  const n = parseInt(b) || 400;
  if (n >= 1200) return { color: [1.0, 0.97, 0.88], intensity: 2.4, label: "xTremeLCD 1200+ nit" };
  if (n >= 800)  return { color: [0.95, 0.97, 1.0],  intensity: 1.6 };
  if (n >= 500)  return { color: [0.85, 0.92, 1.0],  intensity: 1.0 };
  if (n >= 300)  return { color: [0.7,  0.82, 1.0],  intensity: 0.7 };
  return               { color: [0.5,  0.65, 0.9],   intensity: 0.4 };
}

function panelBaseColor(type) {
  switch(type) {
    case "OLED":    return [0.03, 0.03, 0.08];
    case "EPD":     return [0.92, 0.91, 0.86];
    case "STN-LCD": return [0.65, 0.78, 0.55];
    default:        return [0.06, 0.12, 0.20];
  }
}

function enclosureProps(mat) {
  switch(mat) {
    case "Steel":   return { color:[0.28,0.32,0.36], rough:0.25, metal:0.90 };
    case "Plastic": return { color:[0.42,0.46,0.50], rough:0.75, metal:0.00 };
    default:        return { color:[0.56,0.64,0.72], rough:0.12, metal:0.92 }; // Aluminum
  }
}

// ─── MAIN RENDERER ────────────────────────────────────────────────────────────
const DisplayRenderer3D = forwardRef(function DisplayRenderer3D(
  { form, surf, exploded, autoRotate, focusLayer, highlightLayer },
  ref
) {
  const mountRef = useRef(null);
  const stateRef = useRef({
    scene: null, renderer: null, camera: null, pivot: null,
    meshes: {}, lights: {},
    rotY: -0.4, rotX: 0.22,
    isDragging: false, lastX: 0, lastY: 0,
    autoRotate: true,
    highlightMeshes: {},
    animFrame: null,
  });
  const [threeReady, setThreeReady] = useState(!!window.THREE);
  const [sceneReady, setSceneReady] = useState(false);
  const [activeLayers, setActiveLayers] = useState([]);

  // Expose camera snap method to parent
  useImperativeHandle(ref, () => ({
    focusOnLayer: (layerKey) => snapToLayer(layerKey),
    pulseLayer: (layerKey) => triggerPulse(layerKey),
  }));

  // Load Three.js
  useEffect(() => {
    if (window.THREE) { setThreeReady(true); return; }
    const s = document.createElement("script");
    s.src = "https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js";
    s.onload = () => setThreeReady(true);
    document.head.appendChild(s);
  }, []);

  // Init scene once
  useEffect(() => {
    if (!threeReady || !mountRef.current) return;
    const THREE = window.THREE;
    const el = mountRef.current;
    const W = el.clientWidth, H = el.clientHeight;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(W, H);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.3;
    renderer.shadowMap.enabled = true;
    el.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(40, W/H, 0.01, 100);
    camera.position.set(0, 0.5, 4.5);
    camera.lookAt(0, 0, 0);

    // Lights
    scene.add(new THREE.AmbientLight(0xffffff, 0.55));
    const key = new THREE.DirectionalLight(0xfff8f0, 1.6);
    key.position.set(-3, 5, 4); key.castShadow = true;
    scene.add(key);
    const fill = new THREE.DirectionalLight(0xd0e8ff, 0.5);
    fill.position.set(4, 1, 3);
    scene.add(fill);
    const rim = new THREE.DirectionalLight(0x6688cc, 0.25);
    rim.position.set(0, -3, -4);
    scene.add(rim);

    // Env sphere
    const envM = new THREE.MeshBasicMaterial({ color: 0xf4f7fc, side: THREE.BackSide, transparent: true, opacity: 0.35 });
    scene.add(new THREE.Mesh(new THREE.SphereGeometry(25, 12, 12), envM));

    // Pivot group
    const pivot = new THREE.Group();
    scene.add(pivot);

    const S = stateRef.current;
    S.scene = scene; S.renderer = renderer; S.camera = camera; S.pivot = pivot;

    // Mouse/touch orbit
    const onDown = (e) => {
      S.isDragging = true;
      S.lastX = e.clientX ?? e.touches?.[0]?.clientX;
      S.lastY = e.clientY ?? e.touches?.[0]?.clientY;
    };
    const onUp = () => { S.isDragging = false; };
    const onMove = (e) => {
      if (!S.isDragging) return;
      const x = e.clientX ?? e.touches?.[0]?.clientX;
      const y = e.clientY ?? e.touches?.[0]?.clientY;
      S.rotY += (x - S.lastX) * 0.009;
      S.rotX = Math.max(-0.85, Math.min(0.85, S.rotX + (y - S.lastY) * 0.009));
      S.lastX = x; S.lastY = y;
    };
    renderer.domElement.addEventListener("mousedown", onDown);
    renderer.domElement.addEventListener("touchstart", onDown, { passive: true });
    window.addEventListener("mouseup", onUp);
    window.addEventListener("touchend", onUp);
    renderer.domElement.addEventListener("mousemove", onMove);
    renderer.domElement.addEventListener("touchmove", onMove, { passive: true });

    // Animate
    let pulseTime = 0;
    const animate = () => {
      S.animFrame = requestAnimationFrame(animate);
      if (S.autoRotate && !S.isDragging) S.rotY += 0.004;
      // Smooth camera approach
      pivot.rotation.y += (S.rotY - pivot.rotation.y) * 0.08;
      pivot.rotation.x += (S.rotX - pivot.rotation.x) * 0.08;

      // Pulse highlight meshes
      pulseTime += 0.05;
      Object.entries(S.highlightMeshes).forEach(([, m]) => {
        if (m?.material) {
          m.material.emissiveIntensity = 0.3 + Math.sin(pulseTime * 3) * 0.25;
        }
      });

      renderer.render(scene, camera);
    };
    animate();

    const onResize = () => {
      const W2 = el.clientWidth, H2 = el.clientHeight;
      if (W2 === 0 || H2 === 0) return;
      camera.aspect = W2 / H2;
      camera.updateProjectionMatrix();
      renderer.setSize(W2, H2);
    };
    window.addEventListener("resize", onResize);

    setSceneReady(true);

    return () => {
      cancelAnimationFrame(S.animFrame);
      window.removeEventListener("mouseup", onUp);
      window.removeEventListener("touchend", onUp);
      window.removeEventListener("resize", onResize);
      renderer.dispose();
      if (el.contains(renderer.domElement)) el.removeChild(renderer.domElement);
    };
  }, [threeReady]);

  // Sync autoRotate prop
  useEffect(() => {
    stateRef.current.autoRotate = autoRotate;
  }, [autoRotate]);

  // Snap camera to layer
  const snapToLayer = (layerKey) => {
    const S = stateRef.current;
    if (!layerKey) return;
    const layer = LAYER_MAP[layerKey];
    if (!layer) return;
    const z = layer.z;
    // Rotate to face the layer directly
    if (z > 0.05) {
      // Front layers — look from front-left slightly elevated
      S.rotY = -0.3;
      S.rotX = 0.15;
    } else if (z < -0.05) {
      // Back layers — flip to see from behind
      S.rotY = Math.PI - 0.2;
      S.rotX = 0.1;
    } else {
      // Panel itself — face-on
      S.rotY = 0;
      S.rotX = 0.08;
    }
  };

  // Pulse highlight
  const triggerPulse = (layerKey) => {
    const S = stateRef.current;
    S.highlightMeshes = {};
    if (!layerKey) return;
    // Find meshes matching the layer key
    Object.entries(S.meshes).forEach(([key, mesh]) => {
      if (key.toLowerCase().includes(layerKey.toLowerCase())) {
        S.highlightMeshes[key] = mesh;
        if (mesh?.material) {
          mesh.material.emissive = new window.THREE.Color(0x4488ff);
          mesh.material.emissiveIntensity = 0.5;
        }
      }
    });
    // Clear after 2.5s
    setTimeout(() => {
      Object.values(S.highlightMeshes).forEach(m => {
        if (m?.material) m.material.emissiveIntensity = 0;
      });
      S.highlightMeshes = {};
    }, 2500);
  };

  // Rebuild geometry when form changes
  useEffect(() => {
    if (!sceneReady) return;
    const THREE = window.THREE;
    const S = stateRef.current;

    // Clear
    Object.values(S.meshes).forEach(m => {
      S.pivot.remove(m);
      m.geometry?.dispose();
      if (Array.isArray(m.material)) m.material.forEach(mat => mat.dispose());
      else m.material?.dispose();
    });
    S.meshes = {};

    const asp = getAspect(form.resolution1);
    const isPortrait = form.orientation === "Portrait" || form.orientation === "Reverse Portrait";
    const BW = asp >= 1 ? 2.6 : 2.6 * asp;
    const BH = asp >= 1 ? 2.6 / asp : 2.6;
    const FW = isPortrait ? BH : BW;
    const FH = isPortrait ? BW : BH;

    const ex = exploded ? 1 : 0;
    const exScale = 5.5;

    const glow = brightnessToGlow(form.brightnessMin);
    const pColor = panelBaseColor(form.panelType);
    const isOLED = form.panelType === "OLED";
    const hasTouch = form.touchType && form.touchType !== "None";
    const hasGlass = hasTouch || !!form.coverGlassMaterial;
    const hasBond = hasTouch && form.coverGlassMaterial;
    const hasEnclosure = form.enclosure && form.enclosure !== "Display Only";
    const eProps = enclosureProps(form.enclosureMaterial);
    const hasAR = !!surf?.antiReflective;
    const hasAG = !!surf?.antiGlare;
    const hasPCAP = form.touchType?.includes("Capacitive");

    const addMesh = (key, geo, mat, zBase, offsetX = 0, offsetY = 0) => {
      const m = new THREE.Mesh(geo, mat);
      m.castShadow = true;
      m.receiveShadow = true;
      const layerZ = LAYER_MAP[key]?.z ?? zBase;
      const zOff = ex * (layerZ - 0) * exScale;
      m.position.set(offsetX, offsetY, layerZ + zOff);
      S.pivot.add(m);
      S.meshes[key] = m;
      return m;
    };

    const mkMat = (color, rough, metal, opacity = 1, emissive = null, emInt = 0) =>
      new THREE.MeshStandardMaterial({
        color: new THREE.Color(...(Array.isArray(color) ? color.map(v => v) : [color])),
        roughness: rough, metalness: metal,
        transparent: opacity < 1, opacity,
        ...(emissive ? { emissive: new THREE.Color(...emissive), emissiveIntensity: emInt } : {}),
      });

    // ── PCB ──
    addMesh("pcb",
      new THREE.BoxGeometry(FW - 0.1, FH - 0.1, 0.03),
      mkMat([0.08, 0.28, 0.12], 0.9, 0.1),
      LAYER_MAP.pcb.z
    );

    // ── BACKLIGHT ──
    if (!isOLED) {
      addMesh("backlight",
        new THREE.BoxGeometry(FW - 0.04, FH - 0.04, 0.04),
        mkMat(glow.color, 0.08, 0.0, 0.95, glow.color, glow.intensity * 0.45),
        LAYER_MAP.backlight.z
      );
    }

    // ── LCD PANEL ──
    const panelEmInt = isOLED ? 0 : glow.intensity * 0.6;
    addMesh("panel",
      new THREE.BoxGeometry(FW, FH, 0.045),
      mkMat(pColor, isOLED ? 0.04 : 0.10, 0.0, 1, isOLED ? pColor : glow.color, panelEmInt),
      LAYER_MAP.panel.z
    );

    // ── SCREEN SURFACE (canvas texture) ──
    const cvW = 512, cvH = Math.round(512 / asp);
    const cv = document.createElement("canvas");
    cv.width = isPortrait ? cvH : cvW;
    cv.height = isPortrait ? cvW : cvH;
    const ctx = cv.getContext("2d");

    const bg = ctx.createLinearGradient(0, 0, cv.width, cv.height);
    if (isOLED) { bg.addColorStop(0, "#000"); bg.addColorStop(1, "#0a0020"); }
    else if (glow.intensity >= 2) { bg.addColorStop(0, "#deeeff"); bg.addColorStop(1, "#b8d8f8"); }
    else { bg.addColorStop(0, "#122244"); bg.addColorStop(1, "#0a1530"); }
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, cv.width, cv.height);

    const tc = isOLED ? "#00E5FF" : glow.intensity >= 2 ? "#1B4FD8" : "#64B5F6";
    ctx.strokeStyle = tc + "22"; ctx.lineWidth = 1;
    const gs = Math.round(cv.width / 12);
    for (let x = 0; x < cv.width; x += gs) { ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,cv.height); ctx.stroke(); }
    for (let y = 0; y < cv.height; y += gs) { ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(cv.width,y); ctx.stroke(); }

    ctx.fillStyle = tc; ctx.textAlign = "center";
    const fh = Math.round(cv.height * 0.07);
    ctx.font = `bold ${fh}px 'IBM Plex Mono', monospace`;
    ctx.fillText(form.application || "DISPLAY LOGIC", cv.width/2, cv.height * 0.28);
    ctx.font = `${Math.round(fh * 0.7)}px 'IBM Plex Mono', monospace`;
    ctx.fillStyle = tc + "99";
    ctx.fillText(form.resolution1 || "1920 × 1080", cv.width/2, cv.height * 0.42);
    ctx.fillText(form.panelType || "TFT-LCD", cv.width/2, cv.height * 0.54);
    if (glow.label) { ctx.fillStyle = tc + "66"; ctx.fillText(glow.label, cv.width/2, cv.height * 0.66); }

    const scrGeo = new THREE.PlaneGeometry(FW - 0.06, FH - 0.06);
    const scrMat = new THREE.MeshStandardMaterial({ map: new THREE.CanvasTexture(cv), roughness: 0.04, transparent: true, opacity: 0.96 });
    const scrMesh = new THREE.Mesh(scrGeo, scrMat);
    scrMesh.position.set(0, 0, LAYER_MAP.panel.z + 0.023 + ex*(LAYER_MAP.panel.z)*exScale*0);
    S.pivot.add(scrMesh);
    S.meshes["screen"] = scrMesh;

    // ── OPTICAL BOND ──
    if (hasBond) {
      addMesh("opticalBond",
        new THREE.BoxGeometry(FW + 0.01, FH + 0.01, 0.025),
        mkMat([0.65, 0.80, 0.95], 0.05, 0.15, 0.2, [0.7, 0.85, 1.0], 0.06),
        LAYER_MAP.opticalBond.z
      );
    }

    // ── TOUCH LAYER ──
    if (hasTouch) {
      const tColor = hasPCAP ? [0.5, 0.75, 0.95] : [0.92, 0.82, 0.68];
      addMesh("touch",
        new THREE.BoxGeometry(FW + 0.01, FH + 0.01, 0.028),
        mkMat(tColor, 0.04, 0.2, hasPCAP ? 0.15 : 0.22, tColor, 0.06),
        LAYER_MAP.touch.z
      );

      // PCAP grid overlay
      if (hasPCAP) {
        const gc = document.createElement("canvas");
        gc.width = 256; gc.height = Math.round(256 / asp);
        const gctx = gc.getContext("2d");
        gctx.strokeStyle = "rgba(80,160,255,0.35)"; gctx.lineWidth = 0.8;
        const step = 18;
        for (let x = 0; x < gc.width; x += step) { gctx.beginPath(); gctx.moveTo(x,0); gctx.lineTo(x,gc.height); gctx.stroke(); }
        for (let y = 0; y < gc.height; y += step) { gctx.beginPath(); gctx.moveTo(0,y); gctx.lineTo(gc.width,y); gctx.stroke(); }
        const gMat = new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(gc), transparent: true, opacity: 0.7, depthWrite: false });
        const gMesh = new THREE.Mesh(new THREE.PlaneGeometry(FW, FH), gMat);
        gMesh.position.set(0, 0, LAYER_MAP.touch.z + 0.015 + ex*(LAYER_MAP.touch.z)*0);
        S.pivot.add(gMesh);
        S.meshes["touchGrid"] = gMesh;
      }
    }

    // ── COVER GLASS ──
    if (hasGlass) {
      const isGorilla = form.coverGlassMaterial?.includes("Gorilla") || form.coverGlassMaterial?.includes("Dragontrail");
      const glassRough = hasAG ? 0.45 : isGorilla ? 0.02 : 0.06;
      const glassColor = hasAR ? [0.82, 0.92, 1.0] : hasAG ? [0.88, 0.90, 0.92] : [0.80, 0.88, 0.95];
      addMesh("coverGlass",
        new THREE.BoxGeometry(FW + 0.03, FH + 0.03, 0.035),
        mkMat(glassColor, glassRough, 0.25, 0.18, glassColor, 0.05),
        LAYER_MAP.coverGlass.z
      );
    }

    // ── AR COATING SHIMMER ──
    if (hasAR) {
      const arMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(0.7, 0.9, 1.0), transparent: true, opacity: 0.07, roughness: 0.0, metalness: 0.95, depthWrite: false });
      const arMesh = new THREE.Mesh(new THREE.PlaneGeometry(FW + 0.04, FH + 0.04), arMat);
      arMesh.position.set(0, 0, LAYER_MAP.arCoating.z + ex * (LAYER_MAP.arCoating.z) * 0);
      S.pivot.add(arMesh);
      S.meshes["arCoating"] = arMesh;
    }

    // ── BEZEL / ENCLOSURE ──
    if (hasEnclosure) {
      const bezelW = 0.16;
      [
        ["bezelTop",   FW + bezelW*2, bezelW, 0.065, 0,               (FH + bezelW)/2],
        ["bezelBot",   FW + bezelW*2, bezelW, 0.065, 0,              -(FH + bezelW)/2],
        ["bezelLeft",  bezelW,        FH,     0.065, -(FW+bezelW)/2,  0],
        ["bezelRight", bezelW,        FH,     0.065,  (FW+bezelW)/2,  0],
      ].forEach(([key, bw, bh, bz, bx, by]) => {
        const m = new THREE.Mesh(
          new THREE.BoxGeometry(bw, bh, bz),
          mkMat(eProps.color, eProps.rough, eProps.metal)
        );
        m.castShadow = true;
        const zOff = ex * (LAYER_MAP.bezel.z) * exScale;
        m.position.set(bx, by, LAYER_MAP.bezel.z + zOff);
        S.pivot.add(m);
        S.meshes[key] = m;
      });

      // Back plate
      const backM = new THREE.Mesh(
        new THREE.BoxGeometry(FW + bezelW*2, FH + bezelW*2, 0.04),
        mkMat(eProps.color.map(v => v * 0.7), eProps.rough * 1.2, eProps.metal)
      );
      const backZ = LAYER_MAP.pcb.z - 0.05;
      const backOff = ex * (backZ) * exScale;
      backM.position.set(0, 0, backZ + backOff);
      S.pivot.add(backM);
      S.meshes["backPlate"] = backM;
    }

    // Update active layer labels for legend
    const active = [];
    active.push("pcb");
    if (!isOLED) active.push("backlight");
    active.push("panel");
    if (hasBond) active.push("opticalBond");
    if (hasTouch) active.push("touch");
    if (hasGlass) active.push("coverGlass");
    if (hasAR) active.push("arCoating");
    if (hasEnclosure) active.push("bezel");
    setActiveLayers(active);

  }, [sceneReady, form, surf, exploded]);

  // Update exploded positions smoothly when explode toggles
  useEffect(() => {
    if (!sceneReady) return;
    const S = stateRef.current;
    const THREE = window.THREE;
    const ex = exploded ? 1 : 0;
    const exScale = 5.5;

    Object.entries(S.meshes).forEach(([key, mesh]) => {
      // Find base layer key
      const baseKey = Object.keys(LAYER_MAP).find(k => key.toLowerCase().startsWith(k.toLowerCase())) || null;
      const layerZ = baseKey ? LAYER_MAP[baseKey].z : null;
      if (layerZ !== null) {
        // Animate position
        const target = layerZ + ex * layerZ * exScale;
        mesh.position.z = mesh.position.z + (target - mesh.position.z) * 0.15;
      }
    });
  });

  // Focus on highlighted layer
  useEffect(() => {
    if (focusLayer) snapToLayer(focusLayer);
    if (highlightLayer) triggerPulse(highlightLayer);
  }, [focusLayer, highlightLayer]);

  if (!threeReady) return (
    <div style={{ width:"100%", height:"100%", display:"flex", alignItems:"center", justifyContent:"center", color:"#94A3B8", fontSize:13 }}>
      Loading 3D engine...
    </div>
  );

  return (
    <div style={{ position:"relative", width:"100%", height:"100%" }}>
      <div ref={mountRef} style={{ width:"100%", height:"100%", cursor:"grab" }} />

      {/* Active Layer Legend — overlaid bottom-left */}
      <div style={{ position:"absolute", bottom:10, left:12, display:"flex", flexWrap:"wrap", gap:"5px 10px", maxWidth:"60%" }}>
        {activeLayers.map(key => (
          <div key={key} style={{ display:"flex", alignItems:"center", gap:5 }}>
            <div style={{ width:7, height:7, borderRadius:2, background:LAYER_MAP[key]?.color || "#888", flexShrink:0 }}/>
            <span style={{ fontSize:9.5, color:"rgba(255,255,255,0.55)", fontFamily:"'IBM Plex Mono',monospace" }}>
              {LAYER_MAP[key]?.label}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
});

export default DisplayRenderer3D;
